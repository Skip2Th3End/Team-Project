package com.example.stankbeast.thegame;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.widget.Toast;

import com.example.stankbeast.thegame.MainActivity;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.net.Socket;
import java.util.ArrayList;

import static android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK;

/**
 * Created by Stankbeast on 18/02/2018.
 */

public class Player {

    public boolean hostPlayer = false;
    String name = null;
    ArrayList<String> names = null;
    public Socket socket = null;
    public DataInputStream input = null;
    public DataOutputStream output = null;
    int score = 3;
    public boolean ready = false;
    public MainActivity main;
    public boolean playingPassTheBomb = false;
    public String forfeit = null;
    public boolean forfeitentered = false;
    public boolean inGame = false;
    public PassTheBomb passTheBomb = null;
    public boolean myTurn = false;
    public Context currentRunning;
    public boolean connectionsMade = false;

    public boolean disconnect = false;

    public PlayerListActivity playerList;

    public Player()
    {

    }

    public Player(String inName, MainActivity inmain)
    {
        //initialises the player with mainActivity and name
        name = inName;
        score = 3;
        main = inmain;
        names = new ArrayList<String>();
        names.add(name);

    }

    public Player(Socket inSocket)
    {
        //initialises the player with a socket
        socket = inSocket;

        try {
            input = new DataInputStream(socket.getInputStream());
            output = new DataOutputStream(socket.getOutputStream());
        }
        catch(IOException e)
        {

        }
        score = 3;

    }

    public void SetName(String inName)
    {
        name = inName;
    }

    public String GetName()
    {
        return name;
    }

    public void SetSocket(Socket inSocket)
    {
        //sets the player socket
        socket = inSocket;
        try
        {
            input = new DataInputStream(inSocket.getInputStream());
            output = new DataOutputStream(inSocket.getOutputStream());
        }
        catch(IOException e)
        {
        }
    }

   /* public void UITask(final String incomingUI)
    {
        //switch statement used for updating the UI on the mainAcitivty
        currentRunning = main;
        final String[] components = incomingUI.split(":");


        main.runOnUiThread(new Runnable() {
            public void run() {

                switch(components[0].toUpperCase()) {
                    case "ALLREADY":
                        main.AllReady();
                        break;

                    case "NAME":
                        if(!names.contains(components[1])) {
                            main.PlayerList(components[1]);
                            names.add(components[1]);
                        }
                        break;

                    case "ALLFORFEITS":
                        if(!inGame) {
                            score = 3;
                            main.PlayPassTheBomb();
                            inGame = true;
                        }
                        break;
                }
            }
        });
    }
*/

    public void UITask(final String incomingUI) {
        //switch statement used for updating the UI on the mainAcitivty
        //currentRunning = main;
        final String[] components = incomingUI.split(":");

        ((Activity)currentRunning).runOnUiThread(new Runnable() {
            public void run() {

        switch (components[0].toUpperCase()) {
            case "ALLREADY":
                PlayerListActivity playerListActivity = (PlayerListActivity) currentRunning;
                playerListActivity.AllReady();
                break;

            case "NAME":
                if (!names.contains(components[1])) {
                    playerListActivity = (PlayerListActivity) currentRunning;
                    playerListActivity.PlayerList(components[1]);
                    names.add(components[1]);
                }
                break;

            case "REMOVE":

                    if(names.contains(components[1]))
                    {
                        names.remove(components[1]);
                    }
                    playerListActivity = (PlayerListActivity) currentRunning;
                    playerListActivity.RemovePlayer(components[1]);

                break;

            case "ALLFORFEITS":
                if (!inGame) {
                    score = 3;
                    ForfeitActivity forfeitActivity = (ForfeitActivity) currentRunning;
                    forfeitActivity.PlayPassTheBomb();
                    inGame = true;
                }
                break;
        }
      }
    });

    }

    public void BombTask(final String incomingUI) {

        //switch statement used for updating the UI on the passTheBomb activity
        final String[] components = incomingUI.split(":");
        currentRunning = passTheBomb;

        ((Activity)currentRunning).runOnUiThread(new Runnable() {
            public void run() {

                switch (components[0].toUpperCase()) {

                    case "CHOSENTIME":
                        passTheBomb.RandomTimeGenerated(components[1]);
                        break;

                    case "CHOSENNAME":
                       passTheBomb.SelectedPlayerToStart(components[1]);
                        break;

                    case "CHOSENQUESTION":
                        passTheBomb.chosenQuestion = components[1];
                        break;
                    case "STARTGAME":
                        passTheBomb.StartGame();
                        break;

                    case "NOTMYTURN":
                        passTheBomb.SortTurn(false);
                        break;

                    case "MYTURN":
                        passTheBomb.SortTurn(true);
                        break;

                    case "SHOWSCOREUI":
                        passTheBomb.ShowScores(components[1], null);
                        break;

                    case "WHOLOST":
                        passTheBomb.ShowScores(null, components[1]);
                        break;

                    case "SHOWLOSER":
                        passTheBomb.ShowLoser(components[1]);
                        break;

                    case "SHOWFORFEIT":
                        passTheBomb.ShowForfeit(components[1]);
                        break;

                }
            }
        });
    }


    public void SendMessage(String msg)
    {
        //used for sending messages to the server
        try
        {
            output.writeUTF(msg);
            output.flush();
        }
        catch(IOException e)
        {
            if(PlayerAdapter.GetPlayer().hostPlayer)
            {
                PassTheBombGameManager.getInstance().RemovePlayer(this);
           //     Toast.makeText(currentRunning, "Client Disconnected", Toast.LENGTH_SHORT).show();
            }

            else
            {
              CloseSocket();
            }
        }
    }

    public boolean HeartBeat()
    {
        try
        {
            int i = input.read();

            if( i == -1)
            {
                CloseSocket();
                return false;
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            CloseSocket();
            return false;
        }
    }

    public void Restart()
    {
        if(connectionsMade) {
            MyApp.disconnect = true;
            ((Activity)currentRunning).finish();
            Intent intent = new Intent((Activity)currentRunning, AddNameActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
            ((Activity)currentRunning).startActivity(intent);
        }

    }

    public void CloseSocket()
    {
        try {
            socket.close();

            if(!PlayerAdapter.GetPlayer().hostPlayer)
            {
                Restart();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void RemovePlayer(String inPlayer)
    {
        PlayerListActivity playerListActivity = (PlayerListActivity) currentRunning;
        playerListActivity.RemovePlayer(inPlayer);

    }

}