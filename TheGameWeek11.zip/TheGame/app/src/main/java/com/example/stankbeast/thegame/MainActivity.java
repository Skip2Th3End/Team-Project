package com.example.stankbeast.thegame;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.wifi.p2p.WifiP2pManager;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    InputMethodManager imm;
    String name;
    ArrayAdapter<String> adapter;
    ListView listView;
    ArrayList<String> listItems;
    TextView playersReady;
    Player player;
    boolean listSet = false;
    ConstraintLayout con;
    Button start;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      //  MyApp.RemoveGroup();
       // MyApp.RemovePersistentGroups();
        //keep screen focus on apo
        start = (Button)findViewById(R.id.btn_PlayGame);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Play();
            }
        });

        PassTheBombGameManager.getInstance().ClearList();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

  /*  @Override
    protected void onResume()
    {
        super.onResume();
        //register the broadcast receiever
        MyApp.InUse(1);
        registerReceiver( MyApp.mReceiver,  MyApp.mIntentFilter);
    }
    /* unregister the broadcast receiver */
  /*  @Override
    protected void onPause()
    {
        super.onPause();
        //unregister the broadcast receiever
        unregisterReceiver( MyApp.mReceiver);
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        MyApp.InUse(-1);
    }*/

    public void Play()
    {
        Intent intent = new Intent(this, AddNameActivity.class);
        startActivity(intent);
    }
}
