package com.example.stankbeast.thegame;

import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ForfeitActivity extends AppCompatActivity {


    InputMethodManager imm;
    String name;
    ArrayAdapter<String> adapter;
    ListView listView;
    ArrayList<String> listItems;
    TextView playersReady;
    Player player;
    boolean listSet = false;
    ConstraintLayout con;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_forfeit_layout);
        player = PlayerAdapter.GetPlayer();
        PlayerAdapter.GetPlayer().currentRunning = this;
        TextView playerToAddForfeit = (TextView)findViewById(R.id.player_forfeit_text);
        playerToAddForfeit.setText(player.GetName() + " please add your forfeit");
        MyApp.gameNotReady = false;
    }

   /* @Override
    protected void onResume()
    {
        super.onResume();
        //register the broadcast receiever
        MyApp.InUse(1);
        registerReceiver( MyApp.mReceiver,  MyApp.mIntentFilter);
    }
    @Override
    protected void onPause()
    {
        super.onPause();
        //unregister the broadcast receiever
        unregisterReceiver( MyApp.mReceiver);
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        MyApp.InUse(-1);
    }
*/
    public void AddForfeit(View v) {
        //this method is triggered by clicking the add button on the add_forfeit layout

        //find the forfeit textbox and error message textview
        EditText forfeitEntered = (EditText) findViewById(R.id.forfeit_add_text);
        TextView errorMessage = (TextView)findViewById(R.id.error_message);

        //check if user has entered something, if they haven't tell them to
     if(Validate()){

            errorMessage.setText("");

            //add forfeit to the list
            if (!player.forfeitentered) {

                player.forfeitentered = true;
                player.forfeit = forfeitEntered.getText().toString();

                //if host player check if all players have entered forfeit
                if (player.hostPlayer) {
                    PassTheBombGameManager.getInstance().ServerPlayerForfeitcheck();
                }

                //if client player send data to server
                else
                {
                    player.SendMessage("FORFEIT:" + forfeitEntered.getText().toString());
                }

                //set view to loading screen
                setContentView(R.layout.loading_screen);
                TextView loadingText = (TextView)findViewById(R.id.txt_loading_text);
                loadingText.setText("Waiting for other players");
            }

            //hide the keyboard once the add button is pressed

        }

    }

    public void PlayPassTheBomb(){

        //opens the Pass The bomb activity
        Intent intent = new Intent(this, PassTheBomb.class);
        startActivity(intent);
        finish();
    }

    public boolean Validate()
    {
        EditText forfeitEntered = (EditText) findViewById(R.id.forfeit_add_text);
        String nameCheck = forfeitEntered.getText().toString();


        if(nameCheck.length() < 3)
        {
            Toast.makeText(this, "Forfeit must be between 3 and 30 characters!", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

}
