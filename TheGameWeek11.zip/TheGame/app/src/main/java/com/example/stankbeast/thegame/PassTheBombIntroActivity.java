package com.example.stankbeast.thegame;

import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;

public class PassTheBombIntroActivity extends AppCompatActivity {

    MediaPlayer tickingTimer;
    MediaPlayer explosion;
    Button ready;
    TextView haveTurn;
    int chosenNumber;
    Player player;
    int timer;
    ConstraintLayout con;
    ProgressBar progressBar;
    static ArrayAdapter<String> bombAdapter;
    ArrayList<String> bombPlayer;
    ListView listBomb;
    boolean showScores = false;
    boolean readyView = false;
    String chosenQuestion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //set pass the bomb instance and get the player instance
        PlayerAdapter.GetPlayer().currentRunning = this;
        player = PlayerAdapter.GetPlayer();

        //method to set the game up
        PlayPassTheBomb();

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    protected void onResume() {
        super.onResume();
        MyApp.InUse(1);
        //register the broadcast receiver
        registerReceiver( MyApp.mReceiver,  MyApp.mIntentFilter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //unregister the broadcast receiver
        unregisterReceiver( MyApp.mReceiver);
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        MyApp.InUse(-1);
    }

    public void PlayPassTheBomb()  {

        //initialise buttons and layouts
        setContentView(R.layout.activity_pass_the_bomb);
        readyView = true;
        progressBar = (ProgressBar)findViewById(R.id.progess_name_decide);
        ready = (Button)findViewById(R.id.button_ready);


        PlayerAdapter.GetPlayer().playingPassTheBomb = true;

        //host players phone is needed to choose a player to go first
        if(player.hostPlayer) {

            //use a timer to account for any delay in data sent
            new CountDownTimer(1000 * 1, 1000) {

                public void onTick(long millisUntilFinished) {

                }

                //once the timer finishes
                public void onFinish() {
                    //chooses a random player, time and question
                    PassTheBombGameManager.getInstance().SetUpPassTheBomb();
                }
            }.start();
        }
    }

    public void SelectedPlayerToStart(String inName)
    {
        //hide loading bar
        progressBar.setVisibility(View.GONE);
        TextView nameChosen = (TextView)findViewById(R.id.name_first_text);

        //changes the layout if it's not correct
        if(!readyView)
        {
            setContentView(R.layout.activity_pass_the_bomb);
        }

        //if the player name is the same as the users, they are first and can start
        if(inName.contains( player.GetName()))
        {
            nameChosen.setText(inName + " you're up first!");
            ready.setVisibility(View.VISIBLE);
            player.myTurn = true;
        }

        else
        {
            nameChosen.setText(inName + " is up first!");
            ready.setVisibility(View.GONE);
            player.myTurn = false;
        }
    }

    public void RandomTimeGenerated(String inTime)
    {
        timer = Integer.parseInt(inTime);
    }

    public void ReadyBomb(View v) {
        //if host player is first, alert rest of devices to start
        if (player.hostPlayer) {
            PassTheBombGameManager.getInstance().StartPassTheBomb();
        }
        //if client player is first, send message to server to alert rest of devices
        else {
            player.SendMessage("STARTGAME");
        }
    }
}
