package com.example.stankbeast.thegame;

import android.content.Context;
import android.content.Intent;
import android.net.wifi.p2p.WifiP2pManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class AddNameActivity extends AppCompatActivity {

    private EditText playerNameText;
    String name;
    InputMethodManager imm;
    Button createGame;
    Button joinGame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_name_find_players);

        MyApp.stopSearching = false;

        if(MyApp.wifiHotspot.isApOn())
        {
            MyApp.wifiHotspot.turnWifiApOff();

        }
        MyApp.wifiHotspot.ForgetNetwork("PTBGameRoom", "");
        playerNameText = (EditText)findViewById(R.id.enter_name);
        playerNameText.requestFocus();

        //MyApp.wifiHotspot.turnWifiApOff();


        MyApp.wifiHotspot.ForgetNetwork("PTBGameRoom", "PlayerJoin");



        if(MyApp.disconnect)
        {
            Toast.makeText(this, "Connect has been lost", Toast.LENGTH_SHORT).show();
            playerNameText.setText(PlayerAdapter.GetPlayer().GetName());
        }


        createGame = (Button)findViewById(R.id.btn_createGame);

        createGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               CreateGame();
            }
        });

        joinGame = (Button)findViewById(R.id.btn_joinGame);
        joinGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JoinGame();
            }
        });
    }


    @Override
    protected void onResume()
    {
        super.onResume();
        //register the broadcast receiever
      //  MyApp.InUse(1);
       // registerReceiver( MyApp.mReceiver,  MyApp.mIntentFilter);
    }
    /* unregister the broadcast receiver */
    @Override
    protected void onPause()
    {
        super.onPause();
        //unregister the broadcast receiever
       // unregisterReceiver( MyApp.mReceiver);
    }

    @Override
    protected void onStop()
    {
        super.onStop();
       // MyApp.InUse(-1);
    }

    public void JoinGame() {

        //initialise the textbox the user will enter their name in
        EditText playerNameText = (EditText) findViewById(R.id.enter_name);

        MyApp.wifiHotspot.TurnWifiOn();
        //ensure text has been entered, this will change eventually to avoid bugs
        if (Validate()) {

            joinGame.setEnabled(false);
            MyApp.stopSearching = false;


            if (MyApp.wifiHotspot.ConnectToNetworkWPA("PTBGameRoom", "PlayerJoin")) {
                MyApp.CheckWifiCheck();

                //get the name entered and create a new player with the string
                name = playerNameText.getText().toString();
                Player player = new Player(name, null);

                //set the player adapter so it can be accessed from anywhere in the code
                PlayerAdapter.SetPlayer(player);
                OpenPlayerLobby();

                //show the loading screen and start searching for devices
                //intialise an instance of the keyboard user interface
                //this will be used to hide the keyboard when it is no longer needed
                imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(playerNameText.getWindowToken(), 0);
            }
        }

        else {

            joinGame.setEnabled(true);
        }
    }


    public void CreateGame() {

       // ChangeName();
        //initialise the textbox the user will enter their name in
        EditText playerNameText = (EditText) findViewById(R.id.enter_name);

        //ensure text has been entered, this will change eventually to avoid bugs
        if (Validate()) {

            //add error message here

            MyApp.stopSearching = false;
            //get the name entered and create a new player with the string
            name = playerNameText.getText().toString();
            Player player = new Player(name, null);

            //set the player adapter so it can be accessed from anywhere in the code
            PlayerAdapter.SetPlayer(player);

            if(MyApp.wifiHotspot.createNewNetwork("PTBGameRoom","PlayerJoin")) {
               MyApp.CheckWifiCheck();
               PlayerAdapter.GetPlayer().hostPlayer = true;
            }
            //show the loading screen and start searching for devices
            OpenPlayerLobby();
           // CreateTheGroup();
            //intialise an instance of the keyboard user interface
            //this will be used to hide the keyboard when it is no longer needed
            imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(playerNameText.getWindowToken(), 0);
        }

    }

    public void Discover()
    {
        //uses the broadcast receiever to search for other devices on Wifi direct
        MyApp.mManager.discoverPeers( MyApp.mChannel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
                OpenPlayerLobby();

            }

            @Override
            public void onFailure(int reasonCode) {
                Toast.makeText(AddNameActivity.this, "Please enable wifi direct in your devices wifi settings", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void CreateTheGroup()
    {
        //uses the broadcast receiver to create a group
        MyApp.mManager.createGroup(MyApp.mChannel, new WifiP2pManager.ActionListener(){

            @Override
            public void onSuccess() {
                WiFiDirectBroadcastReceiver.groupOwner = true;
                ConnectionManager.getInstance().ServerConnection();
                OpenPlayerLobby();
            }

            @Override
            public void onFailure(int i) {
                Toast.makeText(AddNameActivity.this, "Please enable wifi direct in your devices wifi settings", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public void ChangeName()
    {
        try {
            Class[] paramTypes = new Class[3];
            paramTypes[0] = WifiP2pManager.Channel.class;
            paramTypes[1] = String.class;
            paramTypes[2] = WifiP2pManager.ActionListener.class;
            Method setDeviceName = MyApp.mManager.getClass().getMethod(
                    "setDeviceName", paramTypes);
            setDeviceName.setAccessible(true);

            Object arglist[] = new Object[3];
            arglist[0] = MyApp.mChannel;
            arglist[1] = "GameGroupOwner";
            arglist[2] = new WifiP2pManager.ActionListener() {

                @Override
                public void onSuccess() {
                    //LOG.debug("setDeviceName succeeded");
                }

                @Override
                public void onFailure(int reason) {
                    // LOG.debug("setDeviceName failed");
                }
            };

            setDeviceName.invoke(MyApp.mManager, arglist);

        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    public void OpenPlayerLobby()
    {
        finish();
        Intent intent = new Intent(this, PlayerListActivity.class);
        startActivity(intent);
    }

    public boolean Validate()
    {
        EditText playerNameText = (EditText) findViewById(R.id.enter_name);

        String nameCheck = playerNameText.getText().toString();

        if(!MyApp.wifiHotspot.isApOn())
        {
            Toast.makeText(this, "Please turn your wifi on!", Toast.LENGTH_SHORT).show();
            //return false;
        }

        if(nameCheck.length() < 3 || nameCheck.length() > 8)
        {
            Toast.makeText(this, "Name must be between 3 and 8 characters!", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}
