package com.example.stankbeast.thegame;

import android.app.Activity;
import android.os.CountDownTimer;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Stankbeast on 08/03/2018.
 */

public class PassTheBombGameManager {

    //singelton class that controls pass the bomb
    private static final PassTheBombGameManager ourInstance = new PassTheBombGameManager();

    //list of all players connected
    public static ArrayList<Player> players = new ArrayList<Player>();
    public static boolean checking = false;
    public static boolean gameNotReady = true;
    public static boolean running = true;

    //question list
    ArrayList<String> questionList;

    public static PassTheBombGameManager getInstance() {
        return ourInstance;
    }

    private PassTheBombGameManager() {
    }

    public void ClearList()
    {
        players.clear();
    }


    public void CheckPlayerConnections()
    {

        for(Player p : players)
        {
            if(!p.hostPlayer) {
                try {
                    int i = p.input.read();

                    if( i == -1)
                    {
                        RemovePlayer(p);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void PlayerCheck()
    {
        if(players.size() == 1)
        {
            PlayerAdapter.GetPlayer().Restart();
        }
    }
    public void RemovePlayer(Player inPlayer)
    {
       // Toast.makeText(((Activity)PlayerAdapter.GetPlayer().currentRunning), inPlayer.GetName() + " has disconnected", Toast.LENGTH_SHORT).show();

        players.remove(inPlayer);

        if(MyApp.gameNotReady) {
            for (Player p : players) {
                if (!p.hostPlayer) {
                    p.SendMessage("REMOVE:" + inPlayer.GetName());
                }
                else
                {
                    p.RemovePlayer(inPlayer.GetName());
                }
            }
        }
        if(players.size() == 1 & !MyApp.gameNotReady)
        {
            PlayerAdapter.GetPlayer().Restart();
            running = false;
        }
        inPlayer.CloseSocket();

    }
    public void AddPlayer(Player inPlayer)
    {
        //add inPlayer to the list of players
        players.add(inPlayer);

        //for loop that sends any new players name to all players already connected
        for(Player p : players)
        {
            if(!p.hostPlayer)
            {
                try {
                    p.output.writeUTF("NAME:" + inPlayer.GetName());
                }
                catch(IOException e)
                {

                }
            }
        }
    }
    public void ServerPlayerReadycheck()
    {
        int amount = 0;

        //goes through each player to check if they are ready
        for(Player p : players)
        {
            if(p.ready)
            {
                amount++;
            }
        }

        //if all players are ready, send message to all clients to go to forfeits page
        if(amount >= players.size())
        {
            for(Player p : players)
            {
                if(p.hostPlayer)
                {
                    p.UITask("ALLREADY");
                }

                else
                {
                    try{p.output.writeUTF("ALLREADY");
                        p.output.flush();}
                    catch(IOException e)
                    {

                    }
                }
            }
        }
    }


    public void ServerPlayerForfeitcheck()
    {
        int amount = 0;

        //checks to see if all users have entered a forfeit
        for(Player p : players)
        {
            if(p.forfeitentered)
            {
                amount++;
            }
        }

        //if forfiets have been entered, go to pass the bomb page
        if(amount >= players.size())
        {
            for(Player p : players)
            {
                if(p.hostPlayer)
                {
                    p.UITask("ALLFORFEITS");
                }

                else
                {
                    try{p.output.writeUTF("ALLFORFEITS");
                        p.output.flush();}
                    catch(IOException e)
                    {

                    }
                }
            }
        }
    }

    public void SetUpPassTheBomb() {

        //gets random name, time and question
        String chosenName = RandomPlayer();
        int chosenTime = RandomTime();
        String chosenQuestion = RandomQuestion();

        //sends player, time and question to all users
        for (Player p : players) {

            if (p.hostPlayer) {
                p.BombTask("CHOSENNAME:" + chosenName);
                p.BombTask("CHOSENTIME:" + chosenTime);
                p.BombTask("CHOSENQUESTION:" + chosenQuestion);
            } else {

                try {
                    p.output.writeUTF("CHOSENNAME:" + chosenName);
                    p.output.writeUTF("CHOSENTIME:" + chosenTime);
                    p.output.writeUTF("CHOSENQUESTION:" + chosenQuestion);
                    p.output.flush();
                } catch (IOException e) {

                }
            }
        }
    }

    public String RandomPlayer(){
        Random random = new Random();
        int chosenNumber;

        //selects a random player to go first
        chosenNumber = random.nextInt(players.size());

        //sets the chosen player turn to true and the rest to false
        for(Player p : players)
        {
            if(p != players.get(chosenNumber))
            {
                p.myTurn = false;
            }
            else
            {
                p.myTurn = true;
            }

        }
        return players.get(chosenNumber).GetName();
    }


    public int RandomTime() {
        //gets a random time
        Random random = new Random();
        int chosenNumber;
        return chosenNumber = random.nextInt(20 - 5) + 5;
    }

    public void StartPassTheBomb() {
        //alerts all users device to start the game
        for (Player p : players) {
            if (p.hostPlayer) {
                p.BombTask("STARTGAME");
            } else {
                try {
                    p.output.writeUTF("STARTGAME");
                    p.output.flush();
                } catch (IOException e) {

                }
            }
        }
    }

    public void SortTurn()
    {
        int count = 0;
        boolean changed = false;
        boolean changeMade = false;

        //updates turn so the next player has their turn
        for(Player p : players)
        {
            count++;

            //if no change has been made, then set this players turn to false and changed to true
            if(p.myTurn && !changed)
            {
                p.myTurn = false;
                changed = true;
            }

            //if the next player has not had their turn set to true then do so
            if(changed && !changeMade)
            {
                //if the count is less than the list size, then set next players to true
                if(count < players.size())
                {
                    players.get(count).myTurn = true;
                }

                //if the count is higher than the list size, set the first players turn in list to true
                else
                {
                    players.get(0).myTurn = true;
                }

                changeMade = true;
            }
        }

        //sends data to all devices on whos turn it is
        UpdateTurn();
    }

    public void UpdateTurn()
    {
        for(Player p : players)
        {
            //if its the players turn, send data to that device to update the screen
            if(p.myTurn)
            {
                if(p.hostPlayer)
                {
                    p.BombTask("MYTURN");
                }

                else
                {
                    try {
                        p.output.writeUTF("MYTURN");
                        p.output.flush();
                    }
                    catch(IOException e)
                    {

                    }
                }
            }

            //if not then change screen accordingly
            else
            {
                if(p.hostPlayer)
                {
                    p.BombTask("NOTMYTURN");
                }

                else
                {
                    try {
                        p.output.writeUTF("NOTMYTURN");
                        p.output.flush();
                    }
                    catch(IOException e)
                    {}
                }
            }
        }
    }

    public void ShowScore(){

        //shows the scores for each user

        //boolean to check if a player has lost the game
        boolean loserFound = false;

        //string to show who lost the round
        String loser = null;

        //goes through player list and updates the score of who lost
        for (Player p : players) {
            if (p.myTurn) {
                p.score--;
                loser = p.GetName();

                //if a player has a score of less than 1 they have lost the game
                if(p.score < 1)
                {
                    loserFound = true;

                }
            }
        }

        //if a loser of the game has been found, end the game and show the loser
        if (loserFound) {
            ShowLoser(loser);
        } else {

            //else show the scores to each device
            for(Player p : players) {
                for (int i = 0; i < players.size(); i++)
                {
                    if(p.hostPlayer)
                    {
                        p.BombTask("SHOWSCOREUI:" + players.get(i).GetName() + "                " + players.get(i).score);
                        p.BombTask("WHOLOST:" + loser);
                    }

                    else
                    {
                        try {
                            p.output.writeUTF("SHOWSCOREUI:" + players.get(i).GetName() + "                     " + players.get(i).score);
                            p.output.writeUTF("WHOLOST:" + loser);
                            p.output.flush();
                        }
                        catch(IOException e)
                        {}
                    }
                }
            }
        }
    }

    public String RandomForfeit()
    {
        //selects a random forfeit from the list
        Random random = new Random();
        int chosenNumber;

        chosenNumber = random.nextInt(2);

        return players.get(chosenNumber).forfeit;
    }

    public void ShowLoser(String loser)
    {
        //gets a random forfeit
        String forfeitChosen = RandomForfeit();

        //shows the loser and their forfeit to each connected device
        for(Player p : players)
        {
            if(p.hostPlayer)
            {
                p.BombTask("SHOWLOSER:" + loser);
                p.BombTask("SHOWFORFEIT:" + forfeitChosen);
            }

            else
            {
                try {
                    p.output.writeUTF("SHOWLOSER:" + loser);
                    p.output.writeUTF("SHOWFORFEIT:" + forfeitChosen);
                    p.output.flush();
                }
                catch(IOException e)
                {

                }
            }
        }
    }

    public void BombTask(final String incomingUI) {
        final String[] components = incomingUI.split(":");

        //switch statement used for incoming commands from client devices
        switch (components[0].toUpperCase()) {
            case "STARTGAME":
                StartPassTheBomb();
                break;

            case "SORTTURN":
                SortTurn();
                break;
        }

    }

    public void ResetScores()
    {
        //resets all scores to 3
        for(Player p : players)
        {
            p.score = 3;
        }
    }

    public String RandomQuestion()
    {
        //selects a random question from the question list
        questionList = new ArrayList<String>();
        questionList.add("Name as many synonyms for the word 'big' as possible");
        questionList.add("Name as many insults as people");
        questionList.add("Name as many words that rhyme with blue");
        questionList.add("Name as many countries that begin with 'L'");
        questionList.add("Name as many insects as you can");

        Random random = new Random();
        int chosenNumber = random.nextInt(questionList.size());

        return questionList.get(chosenNumber);
    }
}
