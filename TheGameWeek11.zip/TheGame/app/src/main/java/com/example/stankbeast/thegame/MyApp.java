package com.example.stankbeast.thegame;

import android.app.Application;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Set;

/**
 * Created by egwad on 02/03/2018.
 */

public class MyApp extends Application {

    //application class to keep wifi direct connection alive

    public static WifiP2pManager mManager;
    public static WifiP2pManager.Channel mChannel;
    public static BroadcastReceiver mReceiver;
    public static IntentFilter mIntentFilter;
    public static int amountInUse = 0;
    public static boolean stopSearching = false;
    public static boolean disconnect = false;
    public static boolean gameNotReady = true;
    public static boolean running = true;

    public static WifiHotspot wifiHotspot;

    @Override
    public void onCreate() {
        super.onCreate();

        wifiHotspot = new WifiHotspot(this.getApplicationContext());
        //SetUpWifiDirect();
    }

    //method to check if app is open, if it's not close all connections
    public static void InUse(int amount)
    {
        amountInUse = amountInUse + amount;

        if(MyApp.amountInUse < 0)
        {
           wifiHotspot.turnWifiApOff();
        }

    }


    public void SetUpWifiDirect()
    {
        mManager = (WifiP2pManager) getSystemService(Context.WIFI_P2P_SERVICE);
        mChannel = mManager.initialize(this, getMainLooper(), null);
        mReceiver = new WiFiDirectBroadcastReceiver(mManager, mChannel, this);

        mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
        registerReceiver( MyApp.mReceiver,  MyApp.mIntentFilter);
    }

    public static void RemovePersistentGroups() {
        try {
            Method[] methods = WifiP2pManager.class.getMethods();
            for (int i = 0; i < methods.length; i++) {
                if (methods[i].getName().equals("deletePersistentGroup")) {
                    // Remove any persistent group
                    for (int netid = 0; netid < 32; netid++) {
                        methods[i].invoke(mManager, mChannel, netid, null);
                    }
                }
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Removes the current WifiP2pGroup in the WifiP2pChannel.
     */
    public static void RemoveGroup() {

        mManager.removeGroup(mChannel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
            }

            @Override
            public void onFailure(int reason) {
            }
        });

    }

    public static void ResetWifiDirect()
    {
        mManager = null;
        mChannel = null;
        mReceiver = null;
    }

    public void CreateNewWifiApNetwork() {

        if(wifiHotspot.createNewNetwork("SolutionBits","SolutionBits")) {
            CheckWifiCheck();
        }
    }


    public void Join()
    {
        WifiHotspot wifiHotspot = new WifiHotspot(this.getApplicationContext());
        if(wifiHotspot.ConnectToNetworkWPA("SolutionBits", "SolutionBits"))
        {
            CheckConnectedDevice();
        }
    }

    public static void CheckConnectedDevice()
    {
        wifiHotspot.getClientList();


        new CountDownTimer(1000, 1000) {

            public void onTick(long millisUntilFinished) {

            }

            public void onFinish() {
                if(wifiHotspot.noClients) {
                    CheckConnectedDevice();
                }

                else
                {
                   ConnectionManager.getInstance().ClientConnection(wifiHotspot.stringIP);
                }
            }

        }.start();
    }


    public static void CheckWifiCheck()
    {
        final int check = wifiHotspot.getWifiAPState();

        new CountDownTimer(1000, 1000) {

            public void onTick(long millisUntilFinished) {

            }

            public void onFinish() {
                if(PlayerAdapter.GetPlayer().hostPlayer && check == 13) {

                        ConnectionManager.getInstance().ServerConnection();
                        stopSearching = true;

                }

                if(!PlayerAdapter.GetPlayer().hostPlayer && check == 11)
                {
                    CheckConnectedDevice();
                }

                else
                {
                    if(!stopSearching ) {
                        CheckWifiCheck();
                    }
                }
            }

        }.start();
    }

    public static void Disconnect()
    {
        wifiHotspot.Disconnect();
    }

}
