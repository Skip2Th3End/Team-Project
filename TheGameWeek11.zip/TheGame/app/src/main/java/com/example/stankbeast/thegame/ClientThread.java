package com.example.stankbeast.thegame;

import android.util.Log;

import com.example.stankbeast.thegame.MainActivity;
import com.example.stankbeast.thegame.Player;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;

/**
 * Created by Stankbeast on 16/02/2018.
 */

public class ClientThread extends Thread {

    String address;
    int port;
    ArrayList<String> players;
    Player player;

    public ClientThread(String inAddress, int inPort) {

        //assign incoming ip address and port to local variables
        port = inPort;
        address = inAddress;
        players = new ArrayList<String>();
        player =PlayerAdapter.GetPlayer();
    }

    @Override
    public void run() {
        super.run();

        if (address != null && port != 0) {
            try
            {
                //create new socket
                Socket soc = new Socket(address, port);
                soc.setSoTimeout(10*500);
                player.SetSocket(soc);

                // create new instance of the client reader thread, intialise it and start it running
                ClientReader clientRead = new ClientReader(player);
                Thread clientReadThread = new Thread(clientRead);
                clientReadThread.start();

                // create new instance of the client writer thread, intialise it and start it running
                ClientWriter clientWrite = new ClientWriter(player);
                Thread clientWriteThread = new Thread(clientWrite);
                clientWriteThread.start();

                player.connectionsMade = true;
            }

            catch(Exception e)
            {
        String et = e.toString();
            }
        }
    }
}

class ClientWriter implements Runnable {

    Player player = null;

    public ClientWriter(Player inPlayer) {
        player = inPlayer;
    }

    public void run() {
        try {
            //send player name
            player.output.writeUTF("NAME:" + player.GetName());

            //keep stream open
            while (true) {
            }
        } catch (IOException except) {
        }
    }
}

class ClientReader implements Runnable {

    Player player = null;
    boolean running = true;

    public ClientReader(Player inPlayer) {
        player = inPlayer;
    }

    public void run() {
        try {

            //reads messages from the server
            while (running) {
                //if the exception is thrown it means the client has quit
                try {
                    //read incoming strings from server
                    String incomingLine = player.input.readUTF();

                    if(incomingLine != null)
                    {
                        //if player is in game, send string to bombtask method
                        if(player.inGame)
                        {
                            player.BombTask(incomingLine);
                        }

                        //else player is not in game, send string to UItask method
                        else {
                            player.UITask(incomingLine);
                        }
                    }


                }catch(SocketTimeoutException soc)
                {
                    player.SendMessage("Heartbeat");
                }
                catch (IOException ex) {
                  //  if(!player.HeartBeat()) {
                       running = false;

                }
            }
        } catch (Exception except) {
            //player.Restart();
            player.Restart();
            running = false;
        }
    }
}
