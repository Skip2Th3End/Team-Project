package com.example.stankbeast.thegame;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Build;
import android.os.CountDownTimer;
import android.support.annotation.RequiresApi;
import android.support.annotation.RequiresPermission;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class PlayerListActivity extends AppCompatActivity {

    InputMethodManager imm;
    String name;
    ArrayAdapter<String> adapter;
    ListView listView;
    ArrayList<String> listItems;
    TextView playersReady;
    Player player;
    boolean listSet = false;
    boolean playerFound = false;

    Button ready;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        PlayerAdapter.GetPlayer().currentRunning = this;
        player = PlayerAdapter.GetPlayer();

        if(!player.hostPlayer)
        {
            Toast.makeText(PlayerListActivity.this, "Finding game", Toast.LENGTH_SHORT).show();
            FindingPlayersLoading();
            WaitingForConnection();
        }

        else
        {
            Toast.makeText(PlayerListActivity.this, "Created Game", Toast.LENGTH_SHORT).show();
            PlayerList(null);
        }





    }

  /*  @Override
    protected void onResume()
    {
        super.onResume();
        //register the broadcast receiever
        MyApp.InUse(1);
        registerReceiver( MyApp.mReceiver,  MyApp.mIntentFilter);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        //unregister the broadcast receiever
        unregisterReceiver( MyApp.mReceiver);
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        MyApp.InUse(-1);
    }*/

    public void FindingPlayersLoading()
    {
        setContentView(R.layout.loading_screen);
    }

    public void PlayerList(String inPlayers)
    {
        //if the list has not been set it up, create it
        if(!listSet)
        {
            setContentView(R.layout.player_lobby);


            ready = (Button)findViewById(R.id.btn_ready);
            ready.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Ready();
                }
            });
            //set list set to true so it's not created again
            listSet = true;

            //create an instance of the nameList
            listItems = new ArrayList<String>();

            //find the list on screen
            listView = (ListView) findViewById(R.id.listView);

            //intialise an adapter for the list view on screen
            adapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1,
                    listItems) {

                //changes the font, size and colour of the list
                public View getView(int position, View convertView, ViewGroup parent) {
                    // Get the Item from ListView
                    View view = super.getView(position, convertView, parent);

                    // Initialize a TextView for ListView each Item
                    TextView tv = (TextView) view.findViewById(android.R.id.text1);

                    tv.setTypeface(Typeface.create("casual", Typeface.NORMAL));
                    tv.setTextSize(24);
                    tv.setShadowLayer(2.0f, 2.0f, 1.0f, Color.BLACK);
                    tv.setGravity(Gravity.CENTER);
                    tv.setBackgroundResource(R.drawable.list_view_draw);

                    // Set the text color of TextView (ListView Item)
                    tv.setTextColor(Color.WHITE);


                    // Generate ListView Item using TextView
                    return view;
                }
            };

            //set the list view adapter so data can be added to it
            listView.setAdapter(adapter);

            //adds the users name
            adapter.add(player.name);
            playersReady = (TextView)findViewById(R.id.players_ready);
        }

        //adds incoming names from other users
        if(inPlayers != null) {
            adapter.add(inPlayers);
            listView.invalidate();
            playerFound = true;

            if(PlayerAdapter.GetPlayer().hostPlayer)
            {
                //MyApp.CheckPlayerConnectionTimer();
            }

        }
        playersReady.setText(adapter.getCount() + " players found");

    }

    public void Ready() {
        //sends a ready message to the server player
        player.ready = true;

        //if host player, check if all players are ready
        if (player.hostPlayer) {
            PassTheBombGameManager.getInstance().ServerPlayerForfeitcheck();
        }

        //if client player send message to server
        else
        {
            player.SendMessage("READY");
        }
    }

    public void AllReady()
    {
        //triggered when all players are ready, opening the forfeit page
        playersReady.setText("all ready");
        finish();
        Intent intent = new Intent(this, ForfeitActivity.class);
        startActivity(intent);
        //AddForfeitsPage();
    }

    public void WaitingForConnection()
    {
        new CountDownTimer(20000 * 1, 1000) {

            public void onTick(long millisUntilFinished) {

            }

            //once the timer finishes
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            public void onFinish() {
                if(!playerFound)
                {
                    Toast.makeText(PlayerListActivity.this, "No games were found", Toast.LENGTH_SHORT).show();
                    MyApp.stopSearching = true;
                    finish();
                    Intent intent = new Intent(PlayerListActivity.this, AddNameActivity.class);
                    startActivity(intent);


                }
            }
        }.start();
    }

    public void WaitingForPlayer()
    {
        new CountDownTimer(5000 * 1, 1000) {

            public void onTick(long millisUntilFinished) {

            }

            //once the timer finishes
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            public void onFinish() {
                if(!playerFound) {
                    ReDiscover();
                    Toast.makeText(PlayerListActivity.this, "Starting new search", Toast.LENGTH_SHORT).show();
                }
            }
        }.start();
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    public void ReDiscover()
    {
        MyApp.mManager.stopPeerDiscovery(MyApp.mChannel, new WifiP2pManager.ActionListener() {
        @Override
        public void onSuccess() {
            MyApp.mManager.discoverPeers( MyApp.mChannel, new WifiP2pManager.ActionListener() {
                @Override
                public void onSuccess() {

                    WaitingForPlayer();
                }

                @Override
                public void onFailure(int reasonCode) {

                }
            });
        }

        @Override
        public void onFailure(int i) {

        }
    });
    }


    public void RemovePlayer(String inName)
    {
        adapter.remove(inName);
        playersReady.setText(adapter.getCount() + " players found");
    }
}
