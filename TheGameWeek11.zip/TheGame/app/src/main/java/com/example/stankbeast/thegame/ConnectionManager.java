package com.example.stankbeast.thegame;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by egwad on 02/03/2018.
 */

public class ConnectionManager {
    //singleton class to keep sockets alive across activities
    private static final ConnectionManager ourInstance = new ConnectionManager();

    //port number to be used
    static int port = 8989;

    public static ConnectionManager getInstance() {
        return ourInstance;
    }

    private ConnectionManager() {
    }

    //opens the server thread
    public void ServerConnection()
    {
        Thread thread = new ServerThread(port);
        thread.start();
    }

    //opens the client thread
    public void ClientConnection(String inAddress)
    {
        Thread thread = new ClientThread(inAddress, port);
        thread.start();
    }
}
