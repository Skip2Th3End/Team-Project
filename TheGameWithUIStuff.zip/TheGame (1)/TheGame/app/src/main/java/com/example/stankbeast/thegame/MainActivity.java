package com.example.stankbeast.thegame;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.wifi.p2p.WifiP2pManager;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    InputMethodManager imm;
    String name;
    ArrayAdapter<String> adapter;
    ListView listView;
    ArrayList<String> listItems;
    TextView playersReady;
    Player player;
    boolean listSet = false;
    ConstraintLayout con;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //keep screen focus on app
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        //register the broadcast receiever
        MyApp.InUse(1);
        registerReceiver( MyApp.mReceiver,  MyApp.mIntentFilter);
    }
    /* unregister the broadcast receiver */
    @Override
    protected void onPause()
    {
        super.onPause();
        //unregister the broadcast receiever
        unregisterReceiver( MyApp.mReceiver);
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        MyApp.InUse(-1);
    }

    public void Play(View v)
    {
		setContentView(R.layout.add_name_find_players);
        EditText playerNameText = (EditText)findViewById(R.id.enter_name);
        playerNameText.requestFocus();

    }

    public void JoinGame(View v)
    {
        //initialise the textbox the user will enter their name in
        EditText playerNameText = (EditText)findViewById(R.id.enter_name);

        //ensure text has been entered, this will change eventually to avoid bugs
        if(playerNameText.getText().length() < 1) {

           //add error message here
        }

        else {

            //get the name entered and create a new player with the string
            name = playerNameText.getText().toString();
            player = new Player(name, this);

            //set the player adapter so it can be accessed from anywhere in the code
            PlayerAdapter.SetPlayer(player);

            //show the loading screen and start searching for devices
            FindingPlayersLoading();
            Discover();

            //intialise an instance of the keyboard user interface
            //this will be used to hide the keyboard when it is no longer needed
            imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(playerNameText.getWindowToken(), 0);
        }
    }


    public void CreateGame(View v)
    {
        //initialise the textbox the user will enter their name in
        EditText playerNameText = (EditText)findViewById(R.id.enter_name);

        //ensure text has been entered, this will change eventually to avoid bugs
        if(playerNameText.getText().length() < 1) {

            //add error message here
        }

        else {

            //get the name entered and create a new player with the string
            name = playerNameText.getText().toString();
            player = new Player(name, this);

            //set the player adapter so it can be accessed from anywhere in the code
            PlayerAdapter.SetPlayer(player);

            //show the loading screen and start searching for devices
            CreateTheGroup();
            PlayerList(null);

            //intialise an instance of the keyboard user interface
            //this will be used to hide the keyboard when it is no longer needed
            imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(playerNameText.getWindowToken(), 0);
        }
    }
    public void FindingPlayersLoading()
    {
        setContentView(R.layout.loading_screen);
    }

    public void Discover()
    {
        //uses the broadcast receiever to search for other devices on Wifi direct
       MyApp.mManager.discoverPeers( MyApp.mChannel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {


            }

            @Override
            public void onFailure(int reasonCode) {

            }
        });
    }

    public void CreateTheGroup()
    {
        //uses the broadcast receiver to create a group
        MyApp.mManager.createGroup(MyApp.mChannel, new WifiP2pManager.ActionListener(){

            @Override
            public void onSuccess() {
                WiFiDirectBroadcastReceiver.groupOwner = true;
                ConnectionManager.getInstance().ServerConnection();
            }

            @Override
            public void onFailure(int i) {

            }
        });
    }
    public void PlayerList(String inPlayers)
    {
        //if the list has not been set it up, create it
        if(!listSet)
        {
            setContentView(R.layout.player_lobby);

            //set list set to true so it's not created again
            listSet = true;

            //create an instance of the nameList
            listItems = new ArrayList<String>();

            //find the list on screen
            listView = (ListView) findViewById(R.id.listView);

            //intialise an adapter for the list view on screen
            adapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1,
                    listItems) {

                //changes the font, size and colour of the list
                public View getView(int position, View convertView, ViewGroup parent) {
                    // Get the Item from ListView
                    View view = super.getView(position, convertView, parent);

                    // Initialize a TextView for ListView each Item
                    TextView tv = (TextView) view.findViewById(android.R.id.text1);

                    tv.setTypeface(Typeface.create("casual", Typeface.NORMAL));
                    tv.setTextSize(24);
                    tv.setShadowLayer(2.0f, 2.0f, 1.0f, Color.BLACK);
                    tv.setGravity(Gravity.CENTER);
                    tv.setBackgroundResource(R.drawable.list_view_draw);

                    // Set the text color of TextView (ListView Item)
                    tv.setTextColor(Color.WHITE);


                    // Generate ListView Item using TextView
                    return view;
                }
            };

            //set the list view adapter so data can be added to it
            listView.setAdapter(adapter);

            //adds the users name
            adapter.add(player.name);
            playersReady = (TextView)findViewById(R.id.players_ready);
        }

        //adds incoming names from other users
        if(inPlayers != null) {
            adapter.add(inPlayers);
        }
        playersReady.setText(adapter.getCount() + " players found");

    }

    public void Ready(View v) {
        //sends a ready message to the server player
        player.ready = true;

        //if host player, check if all players are ready
        if (player.hostPlayer) {
            PassTheBombGameManager.getInstance().ServerPlayerForfeitcheck();
        }

        //if client player send message to server
        else
        {
            player.SendMessage("READY");
        }
    }

    public void AllReady()
    {
        //triggered when all players are ready, opening the forfeit page
        playersReady.setText("all ready");
        AddForfeitsPage();
    }

    public void AddForfeitsPage()
    {
        //open the forfeit layout and ask the user to enter one
        setContentView(R.layout.add_forfeit_layout);
        TextView playerToAddForfeit = (TextView)findViewById(R.id.player_forfeit_text);
        playerToAddForfeit.setText(name + " please add your forfeit");
    }

    public void AddForfeit(View v) {
		//this method is triggered by clicking the add button on the add_forfeit layout 
		
		//find the forfeit textbox and error message textview 
        EditText forfeitEntered = (EditText) findViewById(R.id.forfeit_add_text);
        TextView errorMessage = (TextView)findViewById(R.id.error_message);

        //check if user has entered something, if they haven't tell them to
        if(forfeitEntered.getText().length() < 1)
        {
            errorMessage.setText("Do not enter a blank forfeit");
        }

        else {

            errorMessage.setText("");

            //add forfeit to the list
            if (!player.forfeitentered) {

                player.forfeitentered = true;
                player.forfeit = forfeitEntered.getText().toString();

                //if host player check if all players have entered forfeit
                if (player.hostPlayer) {
                    PassTheBombGameManager.getInstance().ServerPlayerForfeitcheck();
                }

                //if client player send data to server
                else
                {
                    player.SendMessage("FORFEIT:" + forfeitEntered.getText().toString());
                }

                //set view to loading screen
                setContentView(R.layout.loading_screen);
                TextView loadingText = (TextView)findViewById(R.id.txt_loading_text);
                loadingText.setText("Waiting for other players");
            }

            //hide the keyboard once the add button is pressed
            imm.hideSoftInputFromWindow(forfeitEntered.getWindowToken(), 0);
        }

    }

    public void ChooseGame()
    {
        //set the view to the choose game layout
        setContentView(R.layout.choose_game_layout);
    }

    public void PlayPassTheBomb(){

        //opens the Pass The bomb activity
        Intent intent = new Intent(this, PassTheBomb.class);
        startActivity(intent);
    }

}
