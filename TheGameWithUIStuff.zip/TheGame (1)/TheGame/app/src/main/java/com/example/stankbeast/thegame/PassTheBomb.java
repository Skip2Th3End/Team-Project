package com.example.stankbeast.thegame;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.os.Vibrator;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class PassTheBomb extends AppCompatActivity{

    MediaPlayer tickingTimer;
    MediaPlayer explosion;
    Button ready;
    TextView haveTurn;
    int chosenNumber;
    Player player;
    int timer;
    ConstraintLayout con;
    ProgressBar progressBar;
    static ArrayAdapter<String> bombAdapter;
    ArrayList<String> bombPlayer;
    ListView listBomb;
    boolean showScores = false;
    boolean readyView = false;
    String chosenQuestion;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //set pass the bomb instance and get the player instance
        PlayerAdapter.GetPlayer().passTheBomb = this;
        player = PlayerAdapter.GetPlayer();

        //method to set the game up
        PlayPassTheBomb();

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }


    protected void onResume() {
        super.onResume();
        MyApp.InUse(1);
        //register the broadcast receiver
        registerReceiver( MyApp.mReceiver,  MyApp.mIntentFilter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //unregister the broadcast receiver
        unregisterReceiver( MyApp.mReceiver);
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        MyApp.InUse(-1);
    }

    public void PlayPassTheBomb()  {

        //initialise buttons and layouts
        setContentView(R.layout.activity_pass_the_bomb);
        readyView = true;
        progressBar = (ProgressBar)findViewById(R.id.progess_name_decide);
        ready = (Button)findViewById(R.id.button_ready);


        PlayerAdapter.GetPlayer().playingPassTheBomb = true;

        //host players phone is needed to choose a player to go first
        if(player.hostPlayer) {

            //use a timer to account for any delay in data sent
            new CountDownTimer(1000 * 1, 1000) {

                public void onTick(long millisUntilFinished) {

                }

                //once the timer finishes
                public void onFinish() {
                    //chooses a random player, time and question
                    PassTheBombGameManager.getInstance().SetUpPassTheBomb();
                }
            }.start();
        }
    }

    public void SelectedPlayerToStart(String inName)
    {
        //hide loading bar
        progressBar.setVisibility(View.GONE);
        TextView nameChosen = (TextView)findViewById(R.id.name_first_text);

        //changes the layout if it's not correct
        if(!readyView)
        {
            setContentView(R.layout.activity_pass_the_bomb);
        }

        //if the player name is the same as the users, they are first and can start
        if(inName.contains( player.GetName()))
        {
            nameChosen.setText(inName + " you're up first!");
            ready.setVisibility(View.VISIBLE);
            player.myTurn = true;
        }

        else
        {
            nameChosen.setText(inName + " is up first!");
            ready.setVisibility(View.GONE);
            player.myTurn = false;
        }
    }

    public void RandomTimeGenerated(String inTime)
    {
        timer = Integer.parseInt(inTime);
    }

    public void ReadyBomb(View v) {
        //if host player is first, alert rest of devices to start
        if (player.hostPlayer) {
            PassTheBombGameManager.getInstance().StartPassTheBomb();
        }
        //if client player is first, send message to server to alert rest of devices
        else {
            player.SendMessage("STARTGAME");
        }
    }

     public void StartGame()
    {
        //change boolean values used for showing score and starting layout screen
        readyView = false;
        showScores = false;

        //set the view to the pass the bomb start
        setContentView(R.layout.start_pass_the_bomb_layout);
        con = (ConstraintLayout)findViewById(R.id.cont);

        //set the question text
        TextView questionText = (TextView)findViewById(R.id.txt_question_chosen);
        questionText.setText(chosenQuestion);

        haveTurn = (TextView) findViewById(R.id.txt_pass_bomb);

        //sort the players turn
        if(player.myTurn)
        {
            SortTurn(true);
        }

        if(!player.myTurn)
        {
            SortTurn(false);
        }


        //load the explosion ready for when time runs out
        explosion = MediaPlayer.create(this, R.raw.explosion);

        //set the timer to the random time
        chosenNumber = timer;
        new CountDownTimer(1000*chosenNumber, 1000) {

            public void onTick(long millisUntilFinished) {


            }

            //once the timer finishes
            public void onFinish() {


                //stop the timer mp3 and play the explosion
                if (tickingTimer.isPlaying() && tickingTimer != null) {
                    tickingTimer.stop();
                }


                explosion.start();


                //vibrate the phone for 3 seconds
                Vibrator vibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                vibe.vibrate(3000);

                //set the view to the finish page

                if(player.hostPlayer) {
                    PassTheBombGameManager.getInstance().ShowScore();
                }
            }
        }.start();
    }

    public void HaveTurn(View v){

        //if host player, update who's turn is next
        if(player.hostPlayer)
        {
            PassTheBombGameManager.getInstance().SortTurn();
        }

        //if client player, alert server to update the turns
        else
        {
            player.SendMessage("SORTTURN");
        }
    }

    public void SortTurn(boolean yourTurn)
    {
        Animation anim = new AlphaAnimation(0.0f, 1.0f);
        //if its the users turn, turn the ticking on, make the button visible and turn the screen red.
        //if not remove the red background, ticking and button
        if (yourTurn) {
            tickingTimer = MediaPlayer.create(this, R.raw.tickingbomb);
            tickingTimer.start();
            tickingTimer.setLooping(true);
            con.setBackgroundResource(R.drawable.redbackground);
            //con.setBackgroundColor(Color.RED);

            anim.setDuration(50);
            anim.setStartOffset(20);
            anim.setRepeatMode(Animation.REVERSE);
            anim.setRepeatCount(Animation.INFINITE);
            con.startAnimation(anim);
            haveTurn.setVisibility(View.VISIBLE);
        } else {
            if(tickingTimer != null) {
                tickingTimer.stop();
            }
            con.clearAnimation();
            con.setBackgroundResource(R.drawable.background);
            haveTurn.setVisibility(View.GONE);
        }
    }

    public void ShowScores(String incomingName, String loser)
    {
        if(player.myTurn)
        {
            con.clearAnimation();
        }
        //if the scores layout and list has not been set, then set it up
        if(!showScores) {
            setContentView(R.layout.pass_the_bomb_score);

            //list for all players
            bombPlayer = new ArrayList<String>();

            //find the list on screen
            listBomb = (ListView) findViewById(R.id.score_list);

            //intialise an adapter for the list view on screen
            bombAdapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1,
                    bombPlayer) {

                //change font, colour and size of listview
                public View getView(int position, View convertView, ViewGroup parent) {
                    // Get the Item from ListView
                    View view = super.getView(position, convertView, parent);

                    // Initialize a TextView for ListView each Item
                    TextView tv = (TextView) view.findViewById(android.R.id.text1);

                    tv.setTypeface(Typeface.create("casual", Typeface.NORMAL));
                    tv.setTextSize(18);
                    tv.setShadowLayer(2.0f, 2.0f, 1.0f, Color.BLACK);
                    tv.setGravity(Gravity.CENTER);
                    tv.setBackgroundResource(R.drawable.list_view_draw);

                    // Set the text color of TextView (ListView Item)
                    tv.setTextColor(Color.WHITE);
                    return view;
                }
            };


            //set the list view adapter so data can be added to it
            showScores = true;
            listBomb.setAdapter(bombAdapter);
        }

        //string to show which player lost the round
        if(loser != null)
        {
            TextView loserText = (TextView)findViewById(R.id.who_lost_textview);
            loserText.setText(loser + " has lost!");
        }

        //incoming string that shows each players name
        if(incomingName != null) {
            bombAdapter.add(incomingName);
        }

        //show a timer for when the next round starts
        final TextView timerText = (TextView)findViewById(R.id.next_round_in_text);

        new CountDownTimer(1000*8, 1000) {

            public void onTick(long millisUntilFinished) {

                timerText.setText("Next round starts in " + millisUntilFinished / 1000);
            }

            //once the timer finishes
            public void onFinish() {
                PlayPassTheBomb();
            }
        }.start();
    }

    public void ShowLoser(String loser)
    {
        if(player.myTurn)
        {
            con.clearAnimation();
        }
        //the server phone sends the losing players name to all devices to be displayed here
        setContentView(R.layout.pass_the_bomb_finish);
        TextView showLoser = (TextView)findViewById(R.id.txt_loser);
        showLoser.setText(loser + " has lost the game, they must perform the forfeit!");
    }

    public void ShowForfeit(String forfeit)
    {
        //a random forfeit is selected and shown here
        TextView forfeitText = (TextView)findViewById(R.id.txt_forfeit_shown);
        forfeitText.setText(forfeit);
    }

    public void RestartGame(View v)
    {
        //triggered when the another go button is pressed
        PlayPassTheBomb();

        //if host player, reset all scores
        if(player.hostPlayer)
        {
            PassTheBombGameManager.getInstance().ResetScores();
        }
    }
}
