package com.example.stankbeast.thegame;

import android.app.Application;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.p2p.WifiP2pManager;
import android.util.Log;

/**
 * Created by egwad on 02/03/2018.
 */

public class MyApp extends Application {

    //application class to keep wifi direct connection alive

    public static WifiP2pManager mManager;
    public static WifiP2pManager.Channel mChannel;
    public static BroadcastReceiver mReceiver;
    public static IntentFilter mIntentFilter;
    public static int amountInUse = 0;

    @Override
    public void onCreate() {
        super.onCreate();

        mManager = (WifiP2pManager) getSystemService(Context.WIFI_P2P_SERVICE);
        mChannel = mManager.initialize(this, getMainLooper(), null);
        mReceiver = new WiFiDirectBroadcastReceiver(mManager, mChannel, this);

        mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
        registerReceiver( MyApp.mReceiver,  MyApp.mIntentFilter);
    }

    //method to check if app is open, if it's not close all connections
    public static void InUse(int amount)
    {
        amountInUse = amountInUse + amount;

        if(amountInUse == 0)
        { Log.d("i",String.format("disconnecting"));
            mManager.removeGroup( MyApp.mChannel, new WifiP2pManager.ActionListener() {
                @Override
                public void onSuccess() {

                }

                @Override
                public void onFailure(int i) {

                }
            });
        }
    }
}
