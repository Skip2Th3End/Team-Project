package com.example.stankbeast.thegame;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Random;

public class PassTheBomb extends AppCompatActivity {

    MediaPlayer tickingTimer;
    MediaPlayer explosion;
	
	//create lists for incoming data
    ArrayList<String> forfeitList;
    ArrayList<String> questionList;
    ArrayList<Player> playerList;
	
    Random random = new Random();
    int chosenNumber;
    Player player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass_the_bomb);

        //this grabs any data put into the activity from the putextra method
		//using the name you gave to the data on the putextra method you can just create a list and set it using this method below
        playerList = (ArrayList<Player>) getIntent().getSerializableExtra("playerlist");
        forfeitList = (ArrayList<String>) getIntent().getSerializableExtra("forfeitList");

        //randomly select a name from the playerList to go first
        chosenNumber = random.nextInt(playerList.size());
        player = playerList.get(chosenNumber);
        TextView nameChosen = (TextView)findViewById(R.id.name_first_text);
        nameChosen.setText(player.GetName() + " you're up first!");


        //hard coded example questions
        questionList = new ArrayList<String>();

        questionList.add("Name as many synonyms for the word 'big' as possible");
        questionList.add("Name as many words that ryhme with 'stake' as possible");
        questionList.add("Name as many insults as possible");
        questionList.add("Name as many words as you can that end with the letter 'P'");
        questionList.add("Name as many countries starting with the letter 'L'");
    }



    public void StartGame(View v)
    {
		//this is triggered when you press start game in the activity_pass_the_bomb layout
        //set the view to the pass the bomb start
        setContentView(R.layout.start_pass_the_bomb_layout);

        //find the question textview
        TextView question = (TextView)findViewById(R.id.question_text);

        //select a random question from the questionList
        chosenNumber = random.nextInt(questionList.size());
        question.setText(questionList.get(chosenNumber));

        //start the timer mp3 file and keep it on loop until time runs out
        tickingTimer = MediaPlayer.create(this, R.raw.tickingbomb);
        tickingTimer.start();
        tickingTimer.setLooping(true);

        //load the explosion ready for when time runs out
        explosion = MediaPlayer.create(this, R.raw.explosion);

        //set the timer for a time between 5 and 20 seconds, so it doesn't go on forever for testing
        chosenNumber = random.nextInt(20-5)+5;
        new CountDownTimer(1000*chosenNumber, 1000) {

            public void onTick(long millisUntilFinished) {


            }

            //once the timer finishes
            public void onFinish() {


                //stop the timer mp3 and play the explosion
                tickingTimer.stop();
                explosion.start();

                //vibrate the phone for 3 seconds
                Vibrator vibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                vibe.vibrate(3000);

                //set the view to the finish page
                setContentView(R.layout.pass_the_bomb_finish);

                //randomly select a forfeit
                TextView forfeit = (TextView) findViewById(R.id.forfeit_text_view);
                chosenNumber = random.nextInt(forfeitList.size());
                forfeit.setText(forfeitList.get(chosenNumber));

            }
        }.start();
    }

    public void StartAgain(View v)
    {
		//this method is triggered if you press play again
        //set the view back to the start page
        setContentView(R.layout.activity_pass_the_bomb);

        //randomly select a name to start first
        chosenNumber = random.nextInt(playerList.size());
        player = playerList.get(chosenNumber);
        TextView nameChosen = (TextView)findViewById(R.id.name_first_text);
        nameChosen.setText(player.GetName() + " you're up first!");
    }
}
