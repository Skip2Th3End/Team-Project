package com.example.stankbeast.thegame;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

/**
 * Created by Stankbeast on 16/02/2018.
 */

public class ServerThread extends Thread {

    ServerSocket serverSocket = null;
    int port;
    Player newPlayer;
    Player player;


    public ServerThread(int inport) {

        //set the port and get the host player, add it the player list
        port = inport;
        player = PlayerAdapter.GetPlayer();
        player.hostPlayer = true;
        PassTheBombGameManager.getInstance().AddPlayer(player);
    }

    @Override
    public void run() {
        super.run();

        try {
            serverSocket = new ServerSocket(port);

            while (true) {

                //listen for clients and connect them
                Socket socket = serverSocket.accept();

                //once found create a new player and set it's socket
                newPlayer = new Player(socket);

                //create a new reader thread
                ServerReader serverReader = new ServerReader(player, newPlayer);
                Thread serverReadThread = new Thread(serverReader);
                serverReadThread.start();

                //create a new writer thread
                ServerWriter serverWriter = new ServerWriter(newPlayer);
                Thread serverWriterThread = new Thread(serverWriter);
                serverWriterThread.start();
            }
        } catch (IOException e) {

        }
    }
}


class ServerWriter implements Runnable {

    Player newPlayer = null;

    public ServerWriter(Player inNewPlayer) {
        newPlayer = inNewPlayer;
    }

    public void run() {
        try {
            //set up buffreader and output stream so messages can be sent

            //upon connection, send all known connected player names to the client
            for(Player p : PassTheBombGameManager.players)
            {
                if(p != newPlayer)
                {
                    newPlayer.output.writeUTF("NAME:" + p.GetName());
                }
            }

            while (true) {

            }
        } catch (Exception except) {
            //Exception thrown write message to console
            except.printStackTrace();
        }
    }
}

class ServerReader implements Runnable {

    Player player = null;
    Player newPlayer = null;

    public ServerReader(Player inPlayer, Player inNewPlayer) {
        player = inPlayer;
        newPlayer = inNewPlayer;
    }

    public void run() {
        try {

            //reads messages from the connected client
            while (true) {

                try {
                    //reads any messages incoming
                    String incomingLine = newPlayer.input.readUTF();

                    if(incomingLine != null)
                    {
                        //if incoming data contains name, set the new players name
                        if(incomingLine.contains("NAME"))
                        {
                            String[] name = incomingLine.split(":");
                            newPlayer.SetName(name[1]);
                            PassTheBombGameManager.getInstance().AddPlayer(newPlayer);
                        }

                        //if incoming data contains forfiet, set the new players forfeit
                        if(incomingLine.contains("FORFEIT"))
                        {
                            String[] forfeit = incomingLine.split(":");
                            newPlayer.forfeitentered = true;
                            newPlayer.forfeit = forfeit[1];
                            PassTheBombGameManager.getInstance().ServerPlayerForfeitcheck();
                        }

                        //if the incoming data contains ready, set the new player to ready
                        if(incomingLine.contains("READY"))
                        {
                            newPlayer.ready = true;
                            PassTheBombGameManager.getInstance().ServerPlayerReadycheck();
                        }

                        else {
                            //if player is in game, send incoming data to the bomb task method
                            if (player.inGame) {
                                PassTheBombGameManager.getInstance().BombTask(incomingLine);
                            } else {
                                //else send to the UItask
                                player.UITask(incomingLine);
                            }
                        }
                    }
                } catch (IOException ex) {
                }
            }
        } catch (Exception except) {
        }
    }
}
