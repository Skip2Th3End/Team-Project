package com.example.stankbeast.thegame;

import java.io.Serializable;

/**
 * Created by Stankbeast on 12/02/2018.
 */

public class Player implements Serializable {
    private String name;
    private int score;

    public Player(String newName)
    {
        name = newName;
        score = 0;
    }
    public void SetName(String newName)
    {
        name = newName;
    }

    public String GetName()
    {
        return name;
    }

    public void SetScore(int newScore)
    {
        score = newScore;
    }

    public int GetScore()
    {
        return score;
    }
}
