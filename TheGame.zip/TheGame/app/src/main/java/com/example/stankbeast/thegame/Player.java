package com.example.stankbeast.thegame;

import android.app.Application;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import com.example.stankbeast.thegame.MainActivity;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.net.Socket;
import java.util.ArrayList;

/**
 * Created by Stankbeast on 18/02/2018.
 */

public class Player {

    public boolean hostPlayer = false;
    String name = null;
    ArrayList<String> names = null;
    public Socket socket = null;
    public DataInputStream input = null;
    public DataOutputStream output = null;
    int score = 3;
    public boolean ready = false;
    public MainActivity main;
    public boolean playingPassTheBomb = false;
    public String forfeit = null;
    public boolean forfeitentered = false;
    public boolean inGame = false;
    public PassTheBomb passTheBomb = null;
    public boolean myTurn = false;

    public Player()
    {

    }

    public Player(String inName, MainActivity inmain)
    {
        //initialises the player with mainActivity and name
        name = inName;
        score = 3;
        main = inmain;
        names = new ArrayList<String>();
        names.add(name);

    }

    public Player(Socket inSocket)
    {
        //initialises the player with a socket
        socket = inSocket;

        try {
            input = new DataInputStream(socket.getInputStream());
            output = new DataOutputStream(socket.getOutputStream());
        }
        catch(IOException e)
        {

        }
        score = 3;

    }

    public void SetName(String inName)
    {
        name = inName;
    }

    public String GetName()
    {
        return name;
    }

    public void SetSocket(Socket inSocket)
    {
        //sets the player socket
        socket = inSocket;
        try
        {
            input = new DataInputStream(inSocket.getInputStream());
            output = new DataOutputStream(inSocket.getOutputStream());
        }
        catch(IOException e)
        {
        }
    }

    public void UITask(final String incomingUI)
    {
        //switch statement used for updating the UI on the mainAcitivty
        final String[] components = incomingUI.split(":");
        main.runOnUiThread(new Runnable() {
            public void run() {

                switch(components[0].toUpperCase()) {
                    case "ALLREADY":
                        main.AllReady();
                        break;

                    case "NAME":
                        if(!names.contains(components[1])) {
                            main.PlayerList(components[1]);
                            names.add(components[1]);
                        }
                        break;

                    case "ALLFORFEITS":
                        if(!inGame) {
                            score = 3;
                            main.PlayPassTheBomb();
                            inGame = true;
                        }
                        break;
                }
            }
        });
    }


    public void BombTask(final String incomingUI) {

        //switch statement used for updating the UI on the passTheBomb activity
        final String[] components = incomingUI.split(":");

        passTheBomb.runOnUiThread(new Runnable() {
            public void run() {

                switch (components[0].toUpperCase()) {

                    case "CHOSENTIME":
                        passTheBomb.RandomTimeGenerated(components[1]);
                        break;

                    case "CHOSENNAME":
                        passTheBomb.SelectedPlayerToStart(components[1]);
                        break;

                    case "CHOSENQUESTION":
                        passTheBomb.chosenQuestion = components[1];
                        break;
                    case "STARTGAME":
                        passTheBomb.StartGame();
                        break;

                    case "NOTMYTURN":
                        passTheBomb.SortTurn(false);
                        break;

                    case "MYTURN":
                        passTheBomb.SortTurn(true);
                        break;

                    case "SHOWSCOREUI":
                        passTheBomb.ShowScores(components[1], null);
                        break;

                    case "WHOLOST":
                        passTheBomb.ShowScores(null, components[1]);
                        break;

                    case "SHOWLOSER":
                        passTheBomb.ShowLoser(components[1]);
                        break;

                    case "SHOWFORFEIT":
                        passTheBomb.ShowForfeit(components[1]);
                        break;

                }
            }
        });
    }


    public void SendMessage(String msg)
    {
        //used for sending messages to the server
        try
        {
            output.writeUTF(msg);
            output.flush();
        }
        catch(IOException e)
        {

        }
    }
}