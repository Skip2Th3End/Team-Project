package com.example.stankbeast.thegame;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    Button addButton;
    Button startGame;
    ListView listView;
    ArrayList<String> listItems;
    ArrayAdapter<String> adapter;
    ArrayList<Player> playerList;
    ArrayList<String> forfeitList;
    int playerAmount;
    InputMethodManager imm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Play(View v)
    {
		//this method is triggered by clicking the play button on the activity_main layout
		
        //change view to the add player_layout
        setContentView(R.layout.add_players);

        //create an instance of the nameList
        listItems = new ArrayList<String>();

        //find the list on screen
        listView = (ListView)findViewById(R.id.listView);

        //intialise an adapter for the list view on screen
        adapter=new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,
                listItems);

        //set the list view adapter so data can be added to it
        listView.setAdapter(adapter);

        //initialise the player and forfeit list
        playerList = new ArrayList<Player>();
        forfeitList = new ArrayList<String>();

        //hard coded names added to the list on screen, so we don't have to type it in all the time
        adapter.add("Sean");
        adapter.add("Daniel");
        adapter.add("Jared");
		
		//add players to the playerList. This list is used for the new activity 
        playerList.add(new Player("Sean"));
        playerList.add(new Player("Daniel"));
        playerList.add(new Player("Jared"));

        //intialise an instance of the keyboard user interface
        //this will be used to hide the keyboard when it is no longer needed
        imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
    }

    public void AddPlayer(View v)
    {
		//this method is triggered when the add button is clicked on the add_players layout
		
        //find the textbox on screen
        EditText editText = (EditText)findViewById(R.id.editText);

        //ensure text has been entered, this will change eventually to avoid bugs
        if(editText.getText() != null) {
			
            //add the input to the lists
			//this is the same process as the hardcoded names added above, but it adds whatever has been typed in
            Player newPlayer = new Player(editText.getText().toString());
            playerList.add(newPlayer);
            adapter.add(editText.getText().toString());
        }

        //hide the keyboard after the add button is pressed to avoid annoyance
        imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
		
		//set the textbox text to nothing 
        editText.setText("");
    }

    public void AddForfeitsPage(View v)
    {
		//This is triggered by clicking the next button on the add_players layout
		
        //set view to add forfeit layout
        setContentView(R.layout.add_forfeit_layout);

        //set the text box to tell the user which player needs to enter their forfeit
        TextView playerToAddForfeit = (TextView)findViewById(R.id.player_forfeit_text);
        playerToAddForfeit.setText(playerList.get(playerAmount).GetName() + " please add your forfeit");
    }

    public void AddForfeit(View v) {
		//this method is triggered by clicking the add button on the add_forfeit layout 
		
		//find the forfeit textbox and error message textview 
        EditText forfeitEntered = (EditText) findViewById(R.id.forfeit_add_text);
        TextView errorMessage = (TextView)findViewById(R.id.error_message);

        //check if user has entered something, if they haven't tell them to
        if(forfeitEntered.getText().length() < 1)
        {
            errorMessage.setText("Do not enter a blank forfeit");
        }

        else {

            errorMessage.setText("");

            //add forfeit to the list
            forfeitList.add(forfeitEntered.getText().toString());


            //add 1 to this int variable, this is used to go through the playerList 1 by 1
            playerAmount++;


            //if each player has entered their forfeit, go to the game mode selection layout automatically
            if (playerAmount == playerList.size()) {
                forfeitEntered.clearFocus();
				
				//hide the keyboard
                imm.hideSoftInputFromWindow(forfeitEntered.getWindowToken(), 0);
				
				//trigger the ChooseGame method
                ChooseGame();
            }

            //else not all players have entered their forfeit, so generate the next name to enter their forfeit
            else {
                TextView playerToAddForfeit = (TextView) findViewById(R.id.player_forfeit_text);
                playerToAddForfeit.setText(playerList.get(playerAmount).GetName() + " please add your forfeit");
                forfeitEntered.setText("");
            }
        }

    }

    public void ChooseGame()
    {
        //set the view to the choose game layout
        setContentView(R.layout.choose_game_layout);
    }

    public void PlayPassTheBomb(View v)
    {
		//this method is triggered by selecting pass the bomb in the choose_game_layout
        //start the pass the bomb activity

        Intent PassTheBombPage = new Intent (this,PassTheBomb.class);

        //put extra allows you to send data across to the new activity.
		//the first part of the bracket lets you name the data, the second part needs to be the actual data
        PassTheBombPage.putExtra("playerlist",playerList);
        PassTheBombPage.putExtra("forfeitList",forfeitList);
		
		//start the activity
        startActivity(PassTheBombPage);
    }
}
