package com.example.stankbeast.thegame;

import java.util.ArrayList;

/**
 * Created by Stankbeast on 22/02/2018.
 */

public class PlayerAdapter {

    //class used to get player instance across activities
    private static Player player;

    public static Player GetPlayer()
    {
        return player;
    }

    public static void SetPlayer(Player inPlayer)
    {
        PlayerAdapter.player = inPlayer;
    }

}
