package com.example.stankbeast.thegame;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WpsInfo;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pDeviceList;
import android.net.wifi.p2p.WifiP2pGroup;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.net.wifi.p2p.WifiP2pManager.*;
import android.util.Log;
import android.widget.Toast;

import com.example.stankbeast.thegame.MainActivity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Stankbeast on 15/02/2018.
 */

public class WiFiDirectBroadcastReceiver extends BroadcastReceiver {

    private WifiP2pManager mManager;
    private Channel mChannel;
    private MyApp mActivity;
    ArrayList<WifiP2pDevice> devicesConnected;
    boolean connected = false;
    static boolean groupOwner = false;


    public WiFiDirectBroadcastReceiver(WifiP2pManager manager, Channel channel,
                                      MyApp activity) {
        super();
        this.mManager = manager;
        this.mChannel = channel;
        this.mActivity = activity;
        devicesConnected = new ArrayList<WifiP2pDevice>();
    }

    @Override
    public void onReceive(Context context, Intent intent) {

        //method that listens for changes in the wifi direct connection
        String action = intent.getAction();

        if (WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(action)) {
            int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1);
            if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                // Wifi P2P is enabled
            } else {
                // Wi-Fi P2P is not enabled
            }
        }
        //if the peer list has changed, check to see if it's a peer from the game
        else if (WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(action)) {
            if (mManager != null) {
                mManager.requestPeers(mChannel, new WifiP2pManager.PeerListListener() {
                    @Override
                    public void onPeersAvailable(WifiP2pDeviceList peers) {
                        Log.d("i",String.format("PeerListListener: %d peers available, updating device list", peers.getDeviceList().size()));

                        for(WifiP2pDevice device : peers.getDeviceList())
                        {
                            //if the device found is the group owner and this device has not connected yet, connect to it
                            if(!devicesConnected.contains(device) && !connected) {
                                if(device.isGroupOwner()) {
                                    connect(device);
                                }
                            }

                        }
                    }
                });
            }
        }
        //if the connection status has changed, create a client thread to connect to the server device
        else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(action)) {
            Log.d("i",String.format("changed"));
            onAvailable();
        } else if (WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION.equals(action)) {
            // Respond to this device's wifi state changing
        }
    }
    public void connect(final WifiP2pDevice inDev) {
        //gets the incoming device information and sets it up
        final WifiP2pDevice device = inDev;
        WifiP2pConfig config = new WifiP2pConfig();
        config.deviceAddress = device.deviceAddress;
        config.wps.setup = WpsInfo.PBC;

        //connects the chosen device to the users device
        mManager.connect(mChannel, config, new ActionListener() {

            @Override
            public void onSuccess() {
                devicesConnected.add(inDev);
                Log.d("i",String.format("connection made"));
            }

            @Override
            public void onFailure(int reason) {

                Log.d("i", String.format("not connecting", reason));

            }
        });
    }

    public void onAvailable() {
        mManager.requestConnectionInfo(mChannel, new WifiP2pManager.ConnectionInfoListener() {
            @Override
            public void onConnectionInfoAvailable(WifiP2pInfo info) {

                Log.d("i",String.format("request connection information"));
                if (null != info.groupOwnerAddress) {

                    if (info.isGroupOwner && !connected) {

                    }
                    else if(info.groupFormed && !connected){

                        //opens a new client thread
                        ConnectionManager.getInstance().ClientConnection(info.groupOwnerAddress.getHostAddress());
                        connected = true;
                        Log.d("i",String.format("client thread opened"));

                    }
                }
            }
        });
    }
}
