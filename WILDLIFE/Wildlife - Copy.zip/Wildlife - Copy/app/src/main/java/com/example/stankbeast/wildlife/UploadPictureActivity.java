package com.example.stankbeast.wildlife;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class UploadPictureActivity extends Activity {

    Bitmap bitmap;
    ImageView imageView;
    Button send;
    LocationManager locationManager;
    double latitude,longitude;
    Location finalLocation;

    EditText hashText;
    EditText title;
    EditText natureType;

    private static final int REQUEST_LOCATION = 1;
    public static final String UPLOAD_URL = "https://seanthomas900.000webhostapp.com/user";
    public static final String UPLOAD_KEY = "image";
    public static final String TAG = "MY MESSAGE";

    int pictureID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_upload_picture);


        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.height *= 0.8;
        params.width *= 0.8;

        this.getWindow().setAttributes(params);

        //getWindow().setLayout(getWindow, 1600);


        finalLocation = null;
        longitude = 0.0;
        latitude = 0.0;


        hashText = (EditText)findViewById(R.id.editTextHash);
        title = (EditText)findViewById(R.id.editTextTitle);
        natureType = (EditText)findViewById(R.id.editTextType);

        bitmap = ImagesLoaded.getInstance().thePicture;
        imageView = (ImageView)findViewById(R.id.imageView_upload);
        imageView.setImageBitmap(bitmap);

        send = (Button)findViewById(R.id.btn_send);

        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //uploadImage();
                if(!Validate()) {
                    buildAlertMessageNoGps();
                }
            }
        });
    }

    public boolean Validate()
    {
        String stringTitle = title.getText().toString();
        String hash = hashText.getText().toString();
        String species = natureType.getText().toString();
        boolean error = false;

        if(hash.length() < 1)
        {
            hashText.setError("Enter at least one tag");
            error = true;
        }

        if(stringTitle.length() < 3)
        {
            title.setError("Enter a title");
            error = true;
        }


        return error;
    }

    public String getStringImage(Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }

    private void uploadImage(final boolean location){
        class UploadImage extends AsyncTask<Bitmap,Void,String> {

            ProgressDialog loading;
            RequestHandler rh = new RequestHandler(UploadPictureActivity.this);

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(UploadPictureActivity.this, "Uploading Image", "Please wait...",true,true);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);

                JSONArray jsonResponse = null;
                try {
                    jsonResponse = new JSONArray(s);
                    JSONObject obj = (JSONObject) jsonResponse.get(0);
                    pictureID = obj.getInt("picture_id");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                uploadHashTags();
                //SEND NEW RESPONSE
                //create a JSON object and retrieve the incoming details


                loading.dismiss();
                Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(Bitmap... params) {
                Bitmap bitmap = params[0];
                bitmap = Bitmap.createScaledBitmap(bitmap, 850, 700, true);
                String uploadImage = getStringImage(bitmap);

                String natur = natureType.getText().toString();

                if(natur.length() < 1)
                {
                    natur = "Unidentified";
                }
                HashMap<String,String> data = new HashMap<>();
                data.put("guest_id",String.valueOf(ImagesLoaded.getInstance().userID));
                data.put(UPLOAD_KEY, uploadImage);
                data.put("pictureUpload", "yes");
                data.put("title", title.getText().toString());
                data.put("species", natur);
                data.put("longitude",String.valueOf(longitude));
                data.put("latitude",String.valueOf(latitude));



                String result = rh.sendPostRequest(UPLOAD_URL,data);

                return result;
            }
        }

        UploadImage ui = new UploadImage();
        ui.execute(bitmap);
    }


    private void uploadHashTags(){
        class UploadHash extends AsyncTask<Bitmap,Void,String> {

            ProgressDialog loading;
           AddHashTag addHash = new AddHashTag();

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(UploadPictureActivity.this, "Uploading Image", "Please wait...",true,true);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);


                //SEND NEW RESPONSE
                //create a JSON object and retrieve the incoming details


                loading.dismiss();
                finish();
            }

            @Override
            protected String doInBackground(Bitmap... params) {
                Bitmap bitmap = params[0];
                bitmap = Bitmap.createScaledBitmap(bitmap, 850, 700, true);
                String uploadImage = getStringImage(bitmap);

                HashMap<String,String> data = new HashMap<>();
                data.put("picture_id", String.valueOf(pictureID));
                data.put("hashtag_string", hashText.getText().toString());


                String result = addHash.sendPostRequest(UPLOAD_URL,data);

                return result;
            }
        }

       UploadHash hash = new UploadHash();
        hash.execute(bitmap);
    }

    private void getLocation() {

        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            getLocation();

        } else if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {


            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission
                    (this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);

            } else {
                 finalLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                 longitude = finalLocation.getLongitude();
                 latitude = finalLocation.getLatitude();
                uploadImage(true);


            }
        }
    }

    protected void buildAlertMessageNoGps() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Would you like to upload with a location?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                       getLocation();

                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.cancel();
                        uploadImage(false);
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }
}
