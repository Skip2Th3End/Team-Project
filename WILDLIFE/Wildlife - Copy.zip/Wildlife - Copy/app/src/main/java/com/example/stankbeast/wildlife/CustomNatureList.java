package com.example.stankbeast.wildlife;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Stankbeast on 16/05/2018.
 */

public class CustomNatureList extends BaseAdapter {
    private Context context;
    public int picture_id;
    public int guest_id;
    public String comment;

    public CustomNatureList(Context c) {
        context = c;
    }

    //---returns the number of images---
    public int getCount() {
        return ImagesLoaded.getInstance().NatureList.size();
    }

    //---returns the ID of an item---
    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    //---returns an ImageView view---
    @SuppressLint("ResourceType")
    @RequiresApi(api = Build.VERSION_CODES.M)
    public View getView(final int position, View convertView, ViewGroup parent) {

        ImageView imageView;
        final TextView text;

        TextView hashTags;

        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.activity_nature_information, parent, false);

        if(ImagesLoaded.getInstance().NatureList.size() > 0) {
            imageView = (ImageView) rowView.findViewById(R.id.imageNature);
            Bitmap bitmapToScale = ImagesLoaded.getInstance().NatureList.get(position).image;

            bitmapToScale = Bitmap.createScaledBitmap(bitmapToScale, 1450, 1050, true);
            imageView.setAdjustViewBounds(true);

            text = (TextView) rowView.findViewById(R.id.txtNatureName);
            hashTags = (TextView) rowView.findViewById(R.id.txtinformation);
            text.setText(ImagesLoaded.getInstance().NatureList.get(position).name);
            hashTags.setText(ImagesLoaded.getInstance().NatureList.get(position).information);

            imageView.setImageBitmap(bitmapToScale);
        }

        return rowView;
    }

}