package com.example.stankbeast.wildlife;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;

/**
 * Created by Stankbeast on 16/05/2018.
 */

public class CustomDialog extends Dialog {

    public Activity c;
    public Dialog d;
    ImageView imageView;
    TextView text;
    TextView hashTags;
    ImageClass image;

    public CustomDialog(MapsActivity a, ImageClass inImage) {
        super((Context) a);
        // TODO Auto-generated constructor stub
        this.c = (Activity) a;
        image = inImage;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.picture_dashboard);

        Bitmap bitmapToScale = image.image;

        bitmapToScale = Bitmap.createScaledBitmap(bitmapToScale, 1250, 950, true);
        imageView = (ImageView)findViewById(R.id.imageDash);
        imageView.setAdjustViewBounds(true);

        text = (TextView)findViewById(R.id.txtnameDash);
        text.setText(image.name);


        hashTags = (TextView)findViewById(R.id.txt_hashTags);


        String hash = "";
        for(int i = 0; i < image.hashTags.size(); i++ )
        {
            if(i < 1)
            {
                hash = " " + image.hashTags.get(i);
            }

            else
            {
                hash = hash + " " + image.hashTags.get(i);
            }
        }
        imageView.setImageBitmap(bitmapToScale);

        hashTags.setText(hash);


        ListView listView = (ListView)findViewById(R.id.listView_Comments);
        CustomComment listAdapter = new CustomComment(null, image.photoComments);
        listView.setAdapter(listAdapter);

       image.custom = listAdapter;

        final EditText commentBox = (EditText)findViewById(R.id.editTextDashComment);
        Button addComment = (Button)findViewById(R.id.buttonAddComment);
        addComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            /*    picture_id = ImagesLoaded.getInstance().images.get(position).pictureID;
                comment = commentBox.getText().toString();
                ImagesLoaded.getInstance().AddComment(comment, ImagesLoaded.getInstance().firstName, ImagesLoaded.getInstance().lastName, ImagesLoaded.getInstance().images.get(position).pictureID);
                commentBox.setText("");
                addComment();*/
            }
        });

    }
}