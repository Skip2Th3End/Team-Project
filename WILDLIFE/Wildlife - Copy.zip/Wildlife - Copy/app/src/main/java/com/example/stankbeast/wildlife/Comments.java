package com.example.stankbeast.wildlife;

/**
 * Created by Stankbeast on 16/05/2018.
 */

public class Comments {
    public int picture_id;
    public String name;
    public String comment;

    public Comments(int inId, String first, String last, String inComment)
    {
        picture_id = inId;
        name = first + " " + last;
        comment = inComment;
    }
}
