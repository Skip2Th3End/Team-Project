package com.example.stankbeast.wildlife;

import android.text.TextUtils;
import android.util.Patterns;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Stankbeast on 14/05/2018.
 */

public class UtilityClass {

    public final static boolean isValidEmail(CharSequence target)
    {
        //checks to see if the incoming value resembles an email address
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }


    public String FormatDateMySQL(Date date)
    {
        //formats a date into a mySQl date format
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        return dateFormat.format(date);
    }


    public String FormatTime(int inTime)
    {
        //formats integer to have 0 at the front if less than 10
        String timeString = String.valueOf(inTime);

        if(inTime < 10)
        {
            timeString = "0" + timeString;
        }

        return timeString;
    }

    public String FormatDate(int year, int month, int day)
    {
        //formats 3 int values into a mySql date format
        String yearString = String.valueOf(year);
        String monthString = String.valueOf(month);
        String dayString = String.valueOf(day);

        if(month < 10)
        {
            monthString = "0"+ monthString;
        }

        if(day < 10)
        {

            dayString = "0"+ dayString;
        }

        return yearString + "-" + monthString + "-" + dayString;
    }
}
