package com.example.stankbeast.wildlife;

import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Calendar;

public class RegisterActivity extends AppCompatActivity {
    private EditText txtEmail;
    private EditText txtPassword;
    private EditText txtFirstName;
    private EditText txtLastName;
    private TextView dateChosen;
    private String dateOfBirth;
    UtilityClass utilityClass;;
    Calendar calendar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //initialise editText and utility class
        utilityClass = new UtilityClass();
        txtEmail = (EditText) findViewById(R.id.email);
        txtPassword = (EditText) findViewById(R.id.password);
        txtFirstName = (EditText)findViewById(R.id.txtFirstName);
        txtLastName = (EditText)findViewById(R.id.txtLastName);
        dateChosen = (TextView)findViewById(R.id.selectedDate);
        calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, - 20);
        dateChosen.setText(utilityClass.FormatDate(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DATE)));

    }

    public void CheckRegister(View arg0) {

        // Get text from email and paswsord field
        final String email = txtEmail.getText().toString();
        final String password = txtPassword.getText().toString();
        final String firstName = txtFirstName.getText().toString();
        final String lastName = txtLastName.getText().toString();

        //if entries are valid, attempt to create a new user
        if(Validate(email, password, firstName, lastName)) {
            new Register(this).execute(email, password, firstName, lastName, dateChosen.getText().toString());
        }

    }


    public boolean Validate(String inEmail, String inPassword, String inFirstName, String inLastName)
    {
        //checks all entries to see if they are valid
        boolean noError = true;

        if(inPassword.length() < 6)
        {
            txtPassword.setError("Password must be between 6-12 characters");
            noError = false;
        }

        if(inFirstName.length() < 1)
        {
            txtFirstName.setError("First name cannot be blank");
            noError = false;
        }

        if(inLastName.length() < 1)
        {
            txtLastName.setError("Last name cannot be blank");
            noError = false;
        }

        if(!utilityClass.isValidEmail(inEmail))
        {
            txtEmail.setError("please enter a valid email");
            noError = false;
        }

        return noError;
    }

    public void DatePickRegister(View v)
    {
        //shows a date picker when the user clicks on the date
        DatePickerDialog.OnDateSetListener onDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                calendar.set(year, month, dayOfMonth);
                dateChosen.setText(utilityClass.FormatDate(year, month + 1, dayOfMonth));
            }
        };
        //loads the datePicker
        DatePickerDialog dialog = new DatePickerDialog(this, android.R.style.Theme_Holo_Dialog, onDateSetListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE));

        dialog.show();
    }
}
