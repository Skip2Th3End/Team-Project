package com.example.stankbeast.wildlife;

import android.content.Context;
import android.graphics.Bitmap;

import java.util.ArrayList;

/**
 * Created by Stankbeast on 14/05/2018.
 */

public class ImageClass {
    public Bitmap image;
    public String name;
    public int pictureID;
    public double longitude;
    public double latitude;
    public ArrayList<String> hashTags;

    public ImageClass(Bitmap inImage, String inFirst, String inLast, int inPictureID, double inLat, double inLong, Context inContext)
    {
        image = inImage;
        image = Bitmap.createScaledBitmap(image, 1100, 900, true);
        name = inFirst + " " + inLast;
        pictureID = inPictureID;
        longitude = inLong;
        latitude = inLat;
        hashTags = new ArrayList<String>();
    }
}
