package com.example.stankbeast.wildlife;

import android.graphics.Bitmap;

/**
 * Created by Stankbeast on 14/05/2018.
 */

public class ImageClass {
    public Bitmap image;
    public String name;
    public int pictureID;

    public ImageClass(Bitmap inImage, String inFirst, String inLast, int inPictureID)
    {
        image = inImage;
        image = Bitmap.createScaledBitmap(image, 850, 700, true);
        name = inFirst + " " + inLast;
        pictureID = inPictureID;
    }
}
