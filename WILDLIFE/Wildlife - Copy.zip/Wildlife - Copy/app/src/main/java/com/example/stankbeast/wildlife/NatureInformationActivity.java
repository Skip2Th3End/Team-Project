package com.example.stankbeast.wildlife;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class NatureInformationActivity extends AppCompatActivity {

    ImageView imageView;
    TextView title;
    TextView information;
    Button showall;

    ListView listView;
    CustomNatureList adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nature_information);

        String id = getIntent().getStringExtra("species");

        showall = (Button)findViewById(R.id.btnShowAll);
        showall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent intent = new Intent(NatureInformationActivity.this, DashboardActivity.class);
               intent.putExtra("search", title.getText().toString());
               startActivity(intent);
            }
        });

        imageView = (ImageView)findViewById(R.id.imageNature);
        title = (TextView)findViewById(R.id.txtNatureName);
        information = (TextView)findViewById(R.id.txtinformation);

        GetNatureById(id);

    }

    public void GetNatureById(String ID)
    {
        new GetNature(this).execute(ID);
    }

    public void AddToList(Bitmap bit, String name, String informations, int ID)
    {
        imageView.setImageBitmap(bit);
        title.setText(name);
        information.setText(informations);
    }
}
