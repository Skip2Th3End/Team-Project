package com.example.stankbeast.wildlife;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import com.example.stankbeast.wildlife.LoginActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Stankbeast on 14/05/2018.
 */

public class Login extends AsyncTask<String, String, String> {
    private Context context = null;
    ProgressDialog pdLoading;
    HttpURLConnection conn;
    URL url = null;
    public static final int CONNECTION_TIMEOUT = 10000;
    public static final int READ_TIMEOUT = 15000;
    JSONArray jsonResponse = null;

    public Login(Context inContext) {
        context = inContext;
        pdLoading = new ProgressDialog(context);
    }

    @Override
    protected void onPreExecute()
    {
        super.onPreExecute();

        pdLoading.setMessage("\tLoading...");
        pdLoading.setCancelable(false);
        pdLoading.show();

    }


    @Override
    protected String doInBackground(String... params) {
        try {
            //create the URL and pass the query paramters in
            URL mUrl = new URL("https://seanthomas900.000webhostapp.com/user?email=" + params[0] + "&password=" + params[1] + "&login=yes");

            //create the httpURLconnection and set its method and request property
            HttpURLConnection conn = (HttpURLConnection) mUrl.openConnection();
            conn.setRequestProperty("Content-type", "application/json");
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(30000);

            //set input and output to true
            conn.setDoOutput(true);
            conn.setDoInput(true);

            //connect the httpURL connection
            conn.connect();

            //receive the response code
            int responseCode = conn.getResponseCode();

            //check if response is OK
            if (responseCode == HttpURLConnection.HTTP_OK) {

                //read the response from the server
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                String e = conn.getResponseMessage();

                while ((line = br.readLine()) != null) {
                    sb.append(line + "\n");
                }
                br.close();

                return (sb.toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "exception";
    }

    @Override
    protected void onPostExecute(String result) {

        pdLoading.dismiss();

        //error, something is wrong with the connection
        if (result.equalsIgnoreCase("exception") || result.equalsIgnoreCase("unsuccessful")) {
            Toast.makeText(context, "Connection problem, please try again", Toast.LENGTH_LONG).show();
        }

        //if the response contains error, the password or email or both are incorrect
        else if(result.toLowerCase().contains("error"))
        {
            Toast.makeText(context, "Invalid email or password", Toast.LENGTH_LONG).show();
        }

        //if the response contains the guest_id, it is successful
        else if(result.toLowerCase().contains("guest_id"))
        {
            try
            {
                //create a JSON array
                jsonResponse = new JSONArray(result);

                //create a JSON object and retrieve the incoming details
                JSONObject obj = (JSONObject) jsonResponse.get(0);
                int userId = obj.getInt("guest_id");
                String email = obj.getString("email");
                String firstName = obj.getString("first_name");
                String lastName = obj.getString("last_name");
                String dateOfBirth = obj.getString("date_of_birth");

                //set the user details in the adapter class


            } catch (JSONException e)
            {
                e.printStackTrace();
            }
            Toast.makeText(context, "Logging in", Toast.LENGTH_LONG).show();
            //run the signingIn method in the login activity
            LoginActivity main = (LoginActivity) context;
            main.SigningIn();
        }
    }
}
