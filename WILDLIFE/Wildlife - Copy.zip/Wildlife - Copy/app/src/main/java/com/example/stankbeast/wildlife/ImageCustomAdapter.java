package com.example.stankbeast.wildlife;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Stankbeast on 14/05/2018.
 */

public class ImageCustomAdapter extends BaseAdapter
{
    private Context context;
    public int picture_id;
    public int guest_id;
    public String comment;

    public ImageCustomAdapter(Context c)
    {
        context = c;
    }

    //---returns the number of images---
    public int getCount() {
        return ImagesLoaded.getInstance().images.size();
    }

    //---returns the ID of an item---
    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    //---returns an ImageView view---
    @SuppressLint("ResourceType")
    @RequiresApi(api = Build.VERSION_CODES.M)
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        ImageView imageView;
        final TextView text;
        final TextView textComment;
        ListView listView;
        ArrayAdapter listAdapter;
        ArrayList<String> comments = new ArrayList<String>();

            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View rowView = inflater.inflate(R.layout.picture_dashboard, parent, false);
            imageView = (ImageView)rowView.findViewById(R.id.imageDash);

            imageView.getLayoutParams().width = 850;
            imageView.getLayoutParams().height = 700;
            imageView.setAdjustViewBounds(true);
            text = (TextView)rowView.findViewById(R.id.txtnameDash);
            text.setText(ImagesLoaded.getInstance().images.get(position).name);
            textComment = (TextView)rowView.findViewById(R.id.edittext_AddComment);
            listView = (ListView)rowView.findViewById(R.id.commentList);
            listAdapter = new ArrayAdapter<String>(context,
            android.R.layout.simple_list_item_1, comments);
            listView.setAdapter(listAdapter);
            new GetComment(this, listAdapter).execute(String.valueOf(ImagesLoaded.getInstance().images.get(position).pictureID));



        Button addComment = (Button)rowView.findViewById(R.id.btn_addComment);
        addComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                picture_id = ImagesLoaded.getInstance().images.get(position).pictureID;
                guest_id = 2;
                comment = textComment.getText().toString();
               addComment();
            }
        });


        imageView.setImageBitmap(ImagesLoaded.getInstance().images.get(position).image);

        return rowView;
    }

    private void addComment(){
        class UploadImage extends AsyncTask<Bitmap,Void,String> {

            ProgressDialog loading;
            AddComment addComm = new AddComment();

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);

            }

            @Override
            protected String doInBackground(Bitmap... params) {
                HashMap<String,String> data = new HashMap<>();
                data.put("guest_id", String.valueOf(guest_id));
                data.put("picture_id", String.valueOf(picture_id));
                data.put("comment", comment);

                String result = addComm.sendPostRequest(null,data);

                return result;
            }
        }

        UploadImage ui = new UploadImage();
        ui.execute();
    }
}