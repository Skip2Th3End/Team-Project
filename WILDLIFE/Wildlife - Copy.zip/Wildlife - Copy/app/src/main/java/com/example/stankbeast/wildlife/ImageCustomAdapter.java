package com.example.stankbeast.wildlife;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Stankbeast on 14/05/2018.
 */

public class ImageCustomAdapter extends BaseAdapter
{
    private Context context;
    public int picture_id;
    public int guest_id;
    public String comment;
    CustomComment listAdapter;

    public ImageCustomAdapter(Context c)
    {
        context = c;
    }

    //---returns the number of images---
    public int getCount() {
        return ImagesLoaded.getInstance().images.size();
    }

    //---returns the ID of an item---
    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    //---returns an ImageView view---
    @SuppressLint("ResourceType")
    @RequiresApi(api = Build.VERSION_CODES.M)
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        ImageView imageView;
        final TextView text;
        final TextView textComment;
        ListView listView;

        ArrayList<String> comments = new ArrayList<String>();
        TextView hashTags;

            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View rowView = inflater.inflate(R.layout.picture_dashboard, parent, false);
            imageView = (ImageView)rowView.findViewById(R.id.imageDash);
            Bitmap bitmapToScale = ImagesLoaded.getInstance().images.get(position).image;

            bitmapToScale = Bitmap.createScaledBitmap(bitmapToScale, 1450, 1050, true);
            imageView.setAdjustViewBounds(true);

            text = (TextView)rowView.findViewById(R.id.txtnameDash);
            text.setText(ImagesLoaded.getInstance().images.get(position).name);


            final TextView species = (TextView)rowView.findViewById(R.id.txtSpecies);
            species.setText(ImagesLoaded.getInstance().images.get(position).species);

            species.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(!species.getText().toString().contains("Unidentified")) {
                        ViewSpecies(species.getText().toString());
                    }

                }
            });

            TextView title = (TextView)rowView.findViewById(R.id.txt_title);
            title.setText(ImagesLoaded.getInstance().images.get(position).title);
            hashTags = (TextView)rowView.findViewById(R.id.txt_hashTags);


        String hash = "";
        for(int i = 0; i < ImagesLoaded.getInstance().images.get(position).hashTags.size(); i++ )
        {
            if(i < 1)
            {
                hash = " " + ImagesLoaded.getInstance().images.get(position).hashTags.get(i);
            }

            else
            {
                hash = hash + " " + ImagesLoaded.getInstance().images.get(position).hashTags.get(i);
            }
        }
        imageView.setImageBitmap(bitmapToScale);

        hashTags.setText(hash);



        listView = (ListView)rowView.findViewById(R.id.listView_Comments);
        listAdapter = new CustomComment(context, ImagesLoaded.getInstance().images.get(position).photoComments);
        listView.setAdapter(listAdapter);

        ImagesLoaded.getInstance().images.get(position).custom = listAdapter;

        final EditText commentBox = (EditText)rowView.findViewById(R.id.editTextDashComment);
        Button addComment = (Button)rowView.findViewById(R.id.buttonAddComment);
        addComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                picture_id = ImagesLoaded.getInstance().images.get(position).pictureID;
                comment = commentBox.getText().toString();
                ImagesLoaded.getInstance().AddComment(comment, ImagesLoaded.getInstance().firstName, ImagesLoaded.getInstance().lastName, ImagesLoaded.getInstance().images.get(position).pictureID);
                commentBox.setText("");
               addComment();
            }
        });
        return rowView;
    }

    public void Add()
    {
        listAdapter.notifyDataSetChanged();
    }
    private void addComment(){
        class UploadImage extends AsyncTask<Bitmap,Void,String> {

            ProgressDialog loading;
            AddComment addComm = new AddComment();

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                new GetComment().execute();

            }

            @Override
            protected String doInBackground(Bitmap... params) {
                HashMap<String,String> data = new HashMap<>();
                data.put("guest_id", String.valueOf(ImagesLoaded.getInstance().userID));
                data.put("picture_id", String.valueOf(picture_id));
                data.put("comment", comment);

                String result = addComm.sendPostRequest(null,data);

                return result;
            }
        }

        UploadImage ui = new UploadImage();
        ui.execute();
    }


    public void ViewSpecies(final String spec)
    {
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("Would you like to view information on" + spec + " ?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        Intent intent = new Intent(context, NatureInformationActivity.class);
                        intent.putExtra("species", spec);
                        context.startActivity(intent);

                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.cancel();
                       // uploadImage(false);
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }
}