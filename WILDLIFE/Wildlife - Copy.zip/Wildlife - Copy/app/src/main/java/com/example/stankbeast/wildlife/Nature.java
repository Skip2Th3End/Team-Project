package com.example.stankbeast.wildlife;

import android.graphics.Bitmap;

/**
 * Created by Stankbeast on 16/05/2018.
 */

public class Nature {

    public Bitmap image;
    public String name;
    public String information;
    public int id;


    public Nature(Bitmap inImage, String inName, String inDescription, int inID)
    {
        image = inImage;
        name = inName;
       information = inDescription;
        id = inID;
    }
}
