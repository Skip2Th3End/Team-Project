package com.example.stankbeast.wildlife;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class DashboardActivity extends AppCompatActivity implements View.OnClickListener {

    public static final int PICK_IMAGE = 1;

    private static int RESULT_LOAD_IMAGE = 1;
    public static final String UPLOAD_URL = "https://seanthomas900.000webhostapp.com/user";
    public static final String UPLOAD_KEY = "image";
    public static final String TAG = "MY MESSAGE";
    private int PICK_IMAGE_REQUEST = 1;

    ArrayList<Bitmap> images;

    private Button buttonUpload;
    private Button buttonReload;

    private ImageView imageView;

    private Bitmap bitmap;

    private Uri filePath;
    ListView listViewImages;
    ImageCustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        images = new ArrayList<Bitmap>();
        adapter = new ImageCustomAdapter(this);
        listViewImages = (ListView)findViewById(R.id.listViewImages);
        listViewImages.setAdapter(adapter);

        buttonUpload = (Button) findViewById(R.id.buttonUpload);
        buttonReload = (Button)findViewById(R.id.buttonReload);

        imageView = (ImageView) findViewById(R.id.imageView);

        buttonUpload.setOnClickListener(this);
        buttonReload.setOnClickListener(this);

        GetImages();
    }

    private void showFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    public void GetImages()
    {
        ImagesLoaded.getInstance().images.clear();
        new GetImage(this).execute(bitmap);
    }

    public void AddImage(Bitmap bit, String firstName, String lastName, int inPictureId)
    {
        ImageClass newImage = new ImageClass(bit, firstName, lastName,inPictureId);
        ImagesLoaded.getInstance().images.add(newImage);
        adapter.notifyDataSetChanged();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {

            filePath = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
             //   imageView.setImageBitmap(bitmap);
                buttonUpload.setEnabled(true);
                Intent intent = new Intent(this, UploadPictureActivity.class);
                intent.putExtra("image", bitmap);
                startActivity(intent);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }



    @Override
    public void onClick(View v) {
        if (v == buttonUpload) {

            CharSequence colors[] = new CharSequence[] {"Take Picture", "Gallery"};

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Upload option");
            builder.setItems(colors, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // the user clicked on colors[which]
                    if(which > 0)
                    {
                        showFileChooser();
                    }

                    else
                    {
                        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
                        startActivityForResult(intent, 1);


                    }


                }
            });
            builder.show();



        }

        if(v == buttonReload)
        {
            GetImages();
        }
    }




    public String getStringImage(Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }

   /* private void uploadImage(){
        class UploadImage extends AsyncTask<Bitmap,Void,String>{

            ProgressDialog loading;
            RequestHandler rh = new RequestHandler(DashboardActivity.this);

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(DashboardActivity.this, "Uploading Image", "Please wait...",true,true);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(Bitmap... params) {
                Bitmap bitmap = params[0];
                String uploadImage = getStringImage(bitmap);

                HashMap<String,String> data = new HashMap<>();
                data.put("guest_id", "2");
                data.put(UPLOAD_KEY, uploadImage);
                data.put("pictureUpload", "yes");

                String result = rh.sendPostRequest(UPLOAD_URL,data);

                return result;
            }
        }

        UploadImage ui = new UploadImage();
        ui.execute(bitmap);
    }*/
}