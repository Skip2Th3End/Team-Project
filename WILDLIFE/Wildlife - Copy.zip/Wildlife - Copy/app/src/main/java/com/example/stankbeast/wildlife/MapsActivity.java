package com.example.stankbeast.wildlife;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private static final int REQUEST_LOCATION = 1;

    LocationManager locationManager;
    double latitude,longitude;
    Location finalLocation;
    Button buttonSearch;
    EditText textSearch;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        getLocation();

        buttonSearch = (Button)findViewById(R.id.btn_search_map);
        textSearch = (EditText)findViewById(R.id.editTextMapSearch);
    }


    public void Search(View v)
    {
        SearchImages(textSearch.getText().toString());
    }



    public void GetImages()
    {
        Bitmap bitmap = ImagesLoaded.getInstance().images.get(0).image;
        ImagesLoaded.getInstance().images.clear();
        new GetImage(this, false).execute(bitmap);
    }

    public void SearchImages(String hashtag)
    {
        if(hashtag.length() < 1)
        {
            GetImages();
        }

        else {
            mMap.clear();
            ImagesLoaded.getInstance().images.clear();
            new GetImageByTag(this, false).execute(hashtag);
        }
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        ArrayList<ImageClass> image = ImagesLoaded.getInstance().images;
        // Add a marker in Sydney and move the camera

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                //marker.getSnippet(

               // Dialog dialog = new Dialog(MapsActivity.this);
                //dialog.setContentView(R.layout.picture_dashboard);


                ImageView imageView;
                final TextView text;
                TextView hashTags;

                imageView = (ImageView)findViewById(R.id.imageDash);
                int id = Integer.parseInt(marker.getSnippet());
                ImageClass image = ImagesLoaded.getInstance().FindImageClassByID(id);
                CustomDialog cdd=new CustomDialog(MapsActivity.this, image);
                cdd.show();
               // dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

               // dialog.show();
                return false;
            }
        });
       // mMap.moveCamera(new LatLng(latitude, longitude));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latitude, longitude), 12.0f));
       // mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latitude,longitude), 12.0f));
        ShowMarkers();


    }


    public void ShowMarkers()
    {
        int count = 0;
        for(ImageClass location : ImagesLoaded.getInstance().images) {
            count++;
            MarkerOptions options = new MarkerOptions();

            if(location.latitude != 0.0 && location.longitude != 0.0) {
                options.position(new LatLng(location.latitude, location.longitude));
                options.title(location.name);
                options.snippet(String.valueOf(location.pictureID));
                mMap.addMarker(options);
            }
        }
    }

    private void getLocation() {

        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            getLocation();

        } else if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {


            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission
                    (this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);

            } else {
                finalLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                longitude = -1.49783970;
                latitude = 52.93857880;
            }
        }
    }


}
