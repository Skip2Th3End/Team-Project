package com.example.stankbeast.wildlife;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Stankbeast on 16/05/2018.
 */

public class CustomComment extends BaseAdapter
{
    private Context context;
    public int picture_id;
    public int guest_id;
    public String comment;
    ArrayList<Comments> comments;

    public CustomComment( Context inCon, ArrayList<Comments> inComments)
    {
        comments = inComments;
        context = inCon;
    }

    //---returns the number of images---
    public int getCount() {
        return ImagesLoaded.getInstance().comments.size();
    }

    //---returns the ID of an item---
    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    //---returns an ImageView view---
    @SuppressLint("ResourceType")
    @RequiresApi(api = Build.VERSION_CODES.M)
    public View getView(final int position, View convertView, ViewGroup parent)
    {

        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.comment_layout, parent, false);
        TextView name = (TextView)rowView.findViewById(R.id.txtNameComment);
        TextView comment = (TextView)rowView.findViewById(R.id.txtActualComment);


        if(comments.size() > 0 && position < 1)
        {
            name.setText(comments.get(position).name);
            comment.setText(comments.get(position).comment);
        }


        return rowView;
    }

}