package com.example.stankbeast.wildlife;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    UtilityClass utilityClass;

    private EditText txtEmail;
    private EditText txtPassword;
    private CheckBox saveLogin;
    private SharedPreferences loginPreferences;
    private SharedPreferences.Editor loginPrefsEditor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //initialise editText and utility class
        utilityClass = new UtilityClass();
        txtEmail = (EditText) findViewById(R.id.email);
        txtPassword = (EditText) findViewById(R.id.password);
        saveLogin = (CheckBox) findViewById(R.id.checkBox);

        //initialise variables to save login
        loginPreferences = getSharedPreferences("loginPrefs", MODE_PRIVATE);
        loginPrefsEditor = loginPreferences.edit();

        //check if login details have been previously saved, if true load them
        boolean loginSaved = loginPreferences.getBoolean("saveLogin", false);
        if (loginSaved) {
            txtEmail.setText(loginPreferences.getString("email", ""));
            txtPassword.setText(loginPreferences.getString("password", ""));
            saveLogin.setChecked(true);
        }
    }

    public void CheckLogin(View arg0) {

        // Get text from email and password textbox
        final String email = txtEmail.getText().toString();
        final String password = txtPassword.getText().toString();

        //if entries are valid, check login
        if(Validate(email, password)) {
            //email is valid so check login details
            new Login(this).execute(email, password);
        }
    }


    public void Register(View v)
    {
        //open the register activity upon the create account link being clicked
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
        finish();
    }

    public void SigningIn()
    {
        //if save login is checked, save the details for future login
        if (saveLogin.isChecked()) {
            loginPrefsEditor.putBoolean("saveLogin", true);
            loginPrefsEditor.putString("email", txtEmail.getText().toString());
            loginPrefsEditor.putString("password", txtPassword.getText().toString());
            loginPrefsEditor.commit();
        } else {
            loginPrefsEditor.clear();
            loginPrefsEditor.commit();
        }

        //open calendar activity
        Intent intent = new Intent(this, DashboardActivity.class);
        startActivity(intent);
        finish();
    }

    public boolean Validate(String inEmail, String inPassword)
    {
        //checks the strings to check they are valid
        boolean noError = true;

        if(inPassword.length() < 6)
        {
            txtPassword.setError("Password must be between 6-12 characters");
            noError = false;
        }

        if(!utilityClass.isValidEmail(inEmail))
        {
            txtEmail.setError("please enter a valid email");
            noError = false;
        }

        return noError;
    }
}
