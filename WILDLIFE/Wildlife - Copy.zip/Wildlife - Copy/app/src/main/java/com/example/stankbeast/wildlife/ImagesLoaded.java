package com.example.stankbeast.wildlife;

import android.graphics.Bitmap;

import java.util.ArrayList;

/**
 * Created by Stankbeast on 14/05/2018.
 */

public class ImagesLoaded {
    private static final ImagesLoaded ourInstance = new ImagesLoaded();

    public ArrayList<ImageClass> images = new ArrayList<ImageClass>();
    public Bitmap thePicture;
    public int userID;

    public static ImagesLoaded getInstance() {
        return ourInstance;
    }

    private ImagesLoaded() {
    }

    public Bitmap FindImageByID(int id)
    {
        for(ImageClass ima : images)
        {
            if(id == ima.pictureID)
            {
                return ima.image;
            }
        }

        return null;
    }

    public boolean DoesExist(int id)
    {
        for(ImageClass ima : images)
        {
            if(id == ima.pictureID)
            {
                return true;
            }
        }

        return false;
    }

    public void AddHashTag(int id, String hashtag)
    {
        if(hashtag != null) {
            for (ImageClass ima : images) {
                if (id == ima.pictureID) {
                    String addHash = "#"+hashtag;
                    ima.hashTags.add(addHash);
                }
            }
        }
    }
}
