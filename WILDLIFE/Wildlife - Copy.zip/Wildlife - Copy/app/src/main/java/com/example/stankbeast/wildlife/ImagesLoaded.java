package com.example.stankbeast.wildlife;

import android.graphics.Bitmap;

import java.util.ArrayList;

/**
 * Created by Stankbeast on 14/05/2018.
 */

public class ImagesLoaded {
    private static final ImagesLoaded ourInstance = new ImagesLoaded();

    public ArrayList<ImageClass> images = new ArrayList<ImageClass>();
    public ArrayList<Nature> NatureList = new ArrayList<Nature>();
    public ArrayList<Comments> comments = new ArrayList<>();
    public Bitmap thePicture;
    public int userID;
    public String firstName;
    public String lastName;

    public static ImagesLoaded getInstance() {
        return ourInstance;
    }

    private ImagesLoaded() {
    }

    public void AddComment(String comment, String first, String last, int id)
    {
        Comments newComment = new Comments(id, first, last, comment);

        for(ImageClass imageClass : images)
        {
            if(id == imageClass.pictureID)
            {
                if(!imageClass.photoComments.contains(newComment)) {
                    imageClass.photoComments.add(newComment);
                }

                if(imageClass.custom != null)
                {
                    imageClass.custom.notifyDataSetChanged();
                }
            }
        }
    }
    public Bitmap FindImageByID(int id)
    {
        for(ImageClass ima : images)
        {
            if(id == ima.pictureID)
            {
                return ima.image;
            }
        }

        return null;
    }

    public ImageClass FindImageClassByID(int id)
    {
        for(ImageClass ima : images)
        {
            if(id == ima.pictureID)
            {
                return ima;
            }
        }

        return null;
    }

    public boolean DoesExist(int id)
    {
        for(ImageClass ima : images)
        {
            if(id == ima.pictureID)
            {
                return true;
            }
        }

        return false;
    }

    public void AddHashTag(int id, String hashtag)
    {
        if(hashtag != null) {
            for (ImageClass ima : images) {
                if (id == ima.pictureID) {
                    String addHash = "#"+hashtag;
                    ima.hashTags.add(addHash);
                }
            }
        }
    }

    public Nature FindNatureByID(int id)
    {
        for(Nature ima : NatureList)
        {
            if(id == ima.id)
            {
                return ima;
            }
        }

        return null;
    }

}
