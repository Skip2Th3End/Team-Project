package com.example.stankbeast.wildlife;

import android.graphics.Bitmap;

import java.util.ArrayList;

/**
 * Created by Stankbeast on 14/05/2018.
 */

public class ImagesLoaded {
    private static final ImagesLoaded ourInstance = new ImagesLoaded();

    public ArrayList<Bitmap> images = new ArrayList<Bitmap>();

    public static ImagesLoaded getInstance() {
        return ourInstance;
    }

    private ImagesLoaded() {
    }
}
