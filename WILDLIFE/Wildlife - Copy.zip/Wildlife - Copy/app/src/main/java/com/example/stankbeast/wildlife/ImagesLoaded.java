package com.example.stankbeast.wildlife;

import android.graphics.Bitmap;

import java.util.ArrayList;

/**
 * Created by Stankbeast on 14/05/2018.
 */

public class ImagesLoaded {
    private static final ImagesLoaded ourInstance = new ImagesLoaded();

    public ArrayList<ImageClass> images = new ArrayList<ImageClass>();

    public static ImagesLoaded getInstance() {
        return ourInstance;
    }

    private ImagesLoaded() {
    }
}
